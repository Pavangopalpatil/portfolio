# 🚀 Pavan Gopal Patil - Machine Learning & AI Engineer Portfolio

A cutting-edge, cybernetic, and highly interactive portfolio web application for **Pavan Gopal Patil** (Machine Learning & AI Engineer), featuring **real-time AI simulators**, **interactive 3D neural particles**, **Web Audio synthesizer sound effects**, **PavanOS Developer CLI**, and a multi-role **User Management & Recruiter ATS Suite**.

---

## 🌟 Key Highlights & Engineering Features

### 1. 🧬 Interactive Neural Particle Mesh & Animations
- **2D/3D Canvas Synaptic Network**: Floating neural nodes that calculate euclidean distances, interconnect in real-time, and react dynamically to mouse velocity and cursor coordinates.
- **Glassmorphic Cyber Aesthetics**: Built with Tailwind CSS, dark neon gradients (Cyan `#00f0ff`, Emerald `#10b981`, Deep Purple `#a855f7`), and animated scanlines.
- **Synthesizer Web Audio API**: Subtle tactile sound design (keystrokes, mode shifts, confirmation chords) with a 1-click persistent Mute/Unmute audio controller.

### 2. ⚡ Live Interactive Machine Learning Showcases
- **AgroSmart – AI Soil & Crop Inference Simulator**:
  - Interactive multi-class soil selector (Black, Alluvial, Loamy, Red, Sandy, Clay) based on OpenCV color/contour analysis.
  - Real-time sliders for Nitrogen (N), Phosphorus (P), Potassium (K), Soil pH, and Rainfall.
  - Live Scikit-learn predictive inference (achieving **92–95% classification accuracy**), delivering instant crop recommendations, fertilizer prescriptions, and yield forecasts.
  - Viewable Flask REST API backend endpoint (`/api/predict_crop`).
- **AI Online Exam Proctoring Sandbox**:
  - Multi-modal Computer Vision telemetry monitoring candidate stream at **30+ FPS**.
  - Interactive bounding boxes and toggles for **Mobile Phone Detection** (YOLOv3-Tiny 95.4% confidence), **Multiple-Person Detection**, and **Face Absence**.
  - **Browser Tab-Switch Detection**: Real-time event hooks capturing window blur and tab switching violations.
  - **ReportLab PDF Integrity Audit Generator**: 1-click generation and preview of official printable examination audit certificates with cryptographic digest.

### 3. 👥 Comprehensive User Management System
- **👤 Visitor / Guest Mode (Default)**:
  - Explore projects, run live interactive simulations, and sign the public endorsement **Guestbook**.
- **💼 Recruiter & Hiring Hub**:
  - **Live ATS Resume Matcher**: Paste any job description to instantly calculate compatibility scores, identify matched vs missing keywords, and get ATS hiring recommendations.
  - **Fast-Track Priority Interview Pipeline**: High-priority recruiter invitation dispatcher that bypasses general contact forms.
  - **Project Shortlisting**: 1-click bookmarking tool to curate specific projects for recruitment committee review.
- **🛡️ Admin & Owner Control Panel (Pavan Gopal Patil)**:
  - Protected via secure PIN (default demo PIN: `2028` or `pavan123`).
  - **CRM Lead Management**: View, track status (`New`, `In Review`, `Contacted`, `Archived`), and export incoming recruiter leads to JSON.
  - **Guestbook Moderation**: Moderate visitor recommendations and community feedback.
  - **Live Broadcast Banner Editor**: Dynamically modify the header marquee announcement (e.g. updating internship availability).
  - **Telemetry Analytics**: Real-time tracking of portfolio views, resume downloads, and live demo runs.

### 4. 💻 PavanOS Interactive Developer Terminal
- Embedded CLI supporting commands: `help`, `about`, `skills`, `projects`, `predict --soil black`, `proctor --status`, `cat resume`, `contact`, `hire`, and `sudo admin`.

### 5. 📄 Authentic Formatted Resume Document
- 1-click print-ready (`window.print()`) rendering of Pavan's verified resume with copy-to-clipboard and ATS keyword toggle.

---

## 🛠️ Tech Stack & Tooling

| Layer | Technologies |
|---|---|
| **Frontend UI** | React 19, Tailwind CSS v4, Lucide Icons, Canvas Confetti |
| **Graphics & Audio** | HTML5 Canvas 2D Context, Web Audio API |
| **Data & Persistence** | LocalStorage state engine + companion SQLite persistent database |
| **Backend API (Optional)** | Python 3.12, Flask REST API, CORS middleware |
| **Machine Learning** | Scikit-learn, TensorFlow, PyTorch, NumPy, Pandas |
| **Computer Vision** | OpenCV, YOLOv3-Tiny, Haar Cascade Classifiers |
| **Reporting & Hosting** | ReportLab (PDF), Cloudflare, Vite Build Engine |

---

## 🚀 Quick Start & Local Setup

### 1. Run the Frontend (Vite + React)
```bash
# Navigate to project folder
cd portflio

# Install dependencies (if not already installed)
npm install

# Start Vite development server
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) in your browser.

### 2. Build for Production Deployment
```bash
npm run build
```
The optimized production bundle will be generated in `dist/`, ready for immediate deployment on **Vercel, Netlify, Cloudflare Pages, or GitHub Pages**.

### 3. Run the Companion Python Flask API (Optional)
```bash
cd backend
python -m venv venv
# On Windows:
venv\Scripts\activate
# On Linux/macOS:
source venv/bin/activate

pip install -r requirements.txt
python app.py
```
The REST API will launch on `http://127.0.0.1:5000`.

---

## 👤 Personal Credentials (From Resume)

- **Name**: Pavan Gopal Patil
- **Role**: Machine Learning and AI Engineer
- **Institution**: R. C. Patel Institute of Technology, Shirpur (B.Tech CSE - Data Science, Class of 2028)
- **CGPA**: 7.0 / 10
- **Email**: [pavanpatil3851@gmail.com](mailto:pavanpatil3851@gmail.com)
- **Phone**: +91-9422804881
- **LinkedIn**: [linkedin.com/in/pavan-patil-23a224355](https://linkedin.com/in/pavan-patil-23a224355)
- **GitHub**: [github.com/Pavangopalpatil](https://github.com/Pavangopalpatil)
