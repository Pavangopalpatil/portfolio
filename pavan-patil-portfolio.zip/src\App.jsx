import React, { useState } from 'react';
import ParticleCanvas from './components/ParticleCanvas';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import SkillsSection from './components/SkillsSection';
import ProjectsSection from './components/ProjectsSection';
import CertificationsSection from './components/CertificationsSection';
import GuestbookSection from './components/GuestbookSection';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';

// Modals
import AgroSmartDemoModal from './components/AgroSmartDemoModal';
import ProctorDemoModal from './components/ProctorDemoModal';
import TerminalModal from './components/TerminalModal';
import RecruiterHubModal from './components/RecruiterHubModal';
import AdminDashboardModal from './components/AdminDashboardModal';
import ResumeViewerModal from './components/ResumeViewerModal';

// Context
import { AudioProvider } from './context/AudioContext';
import { UserProvider, useUser } from './context/UserContext';
import { CheckCircle2, AlertCircle, Info, Terminal, Briefcase, FileText } from 'lucide-react';

function PortfolioContent() {
  const { toast } = useUser();

  // Modals state
  const [agroModalOpen, setAgroModalOpen] = useState(false);
  const [proctorModalOpen, setProctorModalOpen] = useState(false);
  const [terminalModalOpen, setTerminalModalOpen] = useState(false);
  const [recruiterModalOpen, setRecruiterModalOpen] = useState(false);
  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [resumeModalOpen, setResumeModalOpen] = useState(false);

  return (
    <div className="relative min-h-screen text-slate-100 flex flex-col justify-between selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Background Interactive Neural Particle Mesh */}
      <ParticleCanvas />

      {/* Subtle Ambient Gradient Background */}
      <div className="fixed inset-0 bg-[#040711]/90 -z-20 pointer-events-none" />
      <div className="fixed top-0 left-1/4 w-[800px] h-[500px] bg-cyan-600/10 blur-[150px] rounded-full pointer-events-none -z-10" />
      <div className="fixed bottom-1/4 right-1/4 w-[700px] h-[450px] bg-purple-600/10 blur-[160px] rounded-full pointer-events-none -z-10" />

      {/* Main Page Layout */}
      <div className="relative z-10 flex flex-col flex-1">
        <Navbar
          onOpenTerminal={() => setTerminalModalOpen(true)}
          onOpenResume={() => setResumeModalOpen(true)}
          onOpenAdminModal={() => setAdminModalOpen(true)}
          onOpenRecruiterHub={() => setRecruiterModalOpen(true)}
        />

        <main className="flex-1">
          <HeroSection
            onOpenAgroDemo={() => setAgroModalOpen(true)}
            onOpenProctorDemo={() => setProctorModalOpen(true)}
            onOpenTerminal={() => setTerminalModalOpen(true)}
            onOpenRecruiterHub={() => setRecruiterModalOpen(true)}
          />

          <AboutSection onOpenResume={() => setResumeModalOpen(true)} />

          <SkillsSection />

          <ProjectsSection
            onOpenAgroDemo={() => setAgroModalOpen(true)}
            onOpenProctorDemo={() => setProctorModalOpen(true)}
          />

          <CertificationsSection />

          <GuestbookSection />

          <ContactSection />
        </main>

        <Footer
          onOpenTerminal={() => setTerminalModalOpen(true)}
          onOpenRecruiterHub={() => setRecruiterModalOpen(true)}
          onOpenAdminModal={() => setAdminModalOpen(true)}
        />
      </div>

      {/* Interactive Modals */}
      <AgroSmartDemoModal
        isOpen={agroModalOpen}
        onClose={() => setAgroModalOpen(false)}
      />

      <ProctorDemoModal
        isOpen={proctorModalOpen}
        onClose={() => setProctorModalOpen(false)}
      />

      <TerminalModal
        isOpen={terminalModalOpen}
        onClose={() => setTerminalModalOpen(false)}
        onOpenRecruiterHub={() => setRecruiterModalOpen(true)}
        onOpenAdminModal={() => setAdminModalOpen(true)}
      />

      <RecruiterHubModal
        isOpen={recruiterModalOpen}
        onClose={() => setRecruiterModalOpen(false)}
        onOpenResume={() => setResumeModalOpen(true)}
      />

      <AdminDashboardModal
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
      />

      <ResumeViewerModal
        isOpen={resumeModalOpen}
        onClose={() => setResumeModalOpen(false)}
      />

      {/* Floating Action Button Dock on Mobile / Corner */}
      <div className="fixed bottom-5 right-5 z-40 flex items-center gap-2 bg-[#091124]/90 backdrop-blur-md p-1.5 rounded-2xl border border-cyan-500/30 shadow-2xl shadow-cyan-950/40">
        <button
          onClick={() => setTerminalModalOpen(true)}
          className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-cyan-400 hover:text-white border border-slate-700 transition-all hover:scale-105"
          title="Open PavanOS CLI Terminal"
        >
          <Terminal className="w-4 h-4" />
        </button>

        <button
          onClick={() => setRecruiterModalOpen(true)}
          className="p-2.5 rounded-xl bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 transition-all hover:scale-105"
          title="Open Recruiter Hub & ATS Matcher"
        >
          <Briefcase className="w-4 h-4" />
        </button>

        <button
          onClick={() => setResumeModalOpen(true)}
          className="p-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold transition-all hover:scale-105"
          title="View & Download Official Resume"
        >
          <FileText className="w-4 h-4" />
        </button>
      </div>

      {/* Toast Notification Notification Pill */}
      {toast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-[#091124] border border-cyan-500/50 text-white font-mono text-xs shadow-2xl animate-in fade-in slide-in-from-bottom-5 duration-200">
          {toast.type === 'error' ? (
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          ) : toast.type === 'info' ? (
            <Info className="w-4 h-4 text-cyan-400 shrink-0" />
          ) : (
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          )}
          <span>{toast.message}</span>
        </div>
      )}

    </div>
  );
}

export default function App() {
  return (
    <AudioProvider>
      <UserProvider>
        <PortfolioContent />
      </UserProvider>
    </AudioProvider>
  );
}
