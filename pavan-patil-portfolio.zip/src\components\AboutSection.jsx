import React from 'react';
import { 
  GraduationCap, 
  Award, 
  Layers, 
  Target, 
  CheckCircle2, 
  BrainCircuit, 
  Server, 
  FileCheck2,
  Sparkles 
} from 'lucide-react';
import { PERSONAL_INFO, EDUCATION } from '../data/portfolioData';
import { useAudio } from '../context/AudioContext';

export default function AboutSection({ onOpenResume }) {
  const { playClick, playHover } = useAudio();

  const coreStrengths = [
    {
      title: "End-to-End ML Pipelines",
      desc: "From exploratory data analysis and feature engineering to model serialization and REST API serving using Flask.",
      icon: Layers,
      color: "cyan"
    },
    {
      title: "Computer Vision & Edge Detection",
      desc: "Real-time webcam video stream inferencing using OpenCV, Haar Cascades, and lightweight YOLOv3-Tiny models.",
      icon: BrainCircuit,
      color: "emerald"
    },
    {
      title: "Full-Stack Web Integration",
      desc: "Deploying user-friendly interfaces connected to SQLite backends, with Cloudflare caching and ReportLab PDF auditing.",
      icon: Server,
      color: "purple"
    },
    {
      title: "Empirical Model Optimization",
      desc: "Hyperparameter tuning, cross-validation, and metric analysis achieving 92–95% accuracy in production deployments.",
      icon: Target,
      color: "amber"
    }
  ];

  return (
    <section id="about" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/50 border border-cyan-500/30 text-xs font-mono text-cyan-400">
            <Sparkles className="w-3.5 h-3.5" />
            <span>BACKGROUND & ACADEMICS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Bridging Machine Learning Research with <span className="text-gradient-cyan">Real-World Software</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Hands-on machine learning engineer specializing in computer vision, deep learning, and predictive models deployed with high reliability.
          </p>
        </div>

        {/* Two Column Layout: Bio & Education */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-16">
          
          {/* Left Column: Detailed Bio & Approach */}
          <div className="lg:col-span-7 space-y-6">
            <div className="rounded-2xl bg-gradient-to-br from-[#0a1124] to-[#070c1a] border border-cyan-500/20 p-7 shadow-xl space-y-5">
              <h3 className="text-xl font-bold text-white flex items-center gap-2.5">
                <span className="h-2 w-2 rounded-full bg-cyan-400"></span>
                Engineering Profile
              </h3>
              
              <p className="text-slate-300 leading-relaxed text-sm sm:text-base font-normal">
                {PERSONAL_INFO.summary}
              </p>

              <p className="text-slate-400 leading-relaxed text-sm">
                My approach combines strong mathematical intuition in statistics with rigorous software engineering. 
                Rather than treating AI models as black boxes in Jupyter notebooks, I specialize in packaging them into 
                lightweight, deployable microservices that handle live camera streams and high-throughput data with low latency.
              </p>

              {/* Bulleted Capabilities from Resume */}
              <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                <div className="flex items-center gap-2 text-slate-300 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Real-time OpenCV webcam monitoring</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>Soil image classification (92-95%)</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>Flask REST API + SQLite pipelines</span>
                </div>
                <div className="flex items-center gap-2 text-slate-300 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800">
                  <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>Browser API violation logging & PDF audits</span>
                </div>
              </div>

              {/* Action */}
              <div className="pt-2">
                <button
                  onClick={() => {
                    playClick();
                    onOpenResume();
                  }}
                  onMouseEnter={playHover}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-500/40 text-cyan-300 font-semibold text-xs transition-all hover:scale-[1.02]"
                >
                  <FileCheck2 className="w-4 h-4" />
                  <span>View Full Formatted Resume Details</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: Education & Institution */}
          <div className="lg:col-span-5 space-y-6">
            <div className="rounded-2xl bg-gradient-to-br from-[#0c1429] to-[#080d1e] border border-cyan-500/20 p-7 shadow-xl space-y-6">
              
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-cyan-950 border border-cyan-500/30 text-cyan-400">
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">Higher Education</h3>
                    <p className="text-xs text-slate-400 font-mono">Academic Track</p>
                  </div>
                </div>
                <span className="text-xs font-mono font-bold px-2.5 py-1 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-500/30">
                  {EDUCATION.period}
                </span>
              </div>

              {/* Institution and Degree */}
              <div className="space-y-3">
                <div>
                  <h4 className="text-base font-bold text-white">
                    {EDUCATION.institution}
                  </h4>
                  <p className="text-xs font-mono text-cyan-400 mt-1">
                    {EDUCATION.degree}
                  </p>
                </div>

                {/* CGPA Badge */}
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-400 block">Cumulative Grade Point Average</span>
                    <span className="text-2xl font-bold font-mono text-cyan-300">{EDUCATION.cgpa}</span>
                  </div>
                  <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                    <Award className="w-5 h-5" />
                  </div>
                </div>

                {/* Highlights */}
                <div className="space-y-2 pt-2">
                  <span className="text-xs font-mono text-slate-400 font-medium">Curricular Focus:</span>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {EDUCATION.highlights.map((h, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-cyan-400 mt-0.5">•</span>
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* 4 Core Pillars Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {coreStrengths.map((pillar, idx) => {
            const Icon = pillar.icon;
            return (
              <div 
                key={idx}
                className="rounded-xl bg-[#091124]/90 border border-slate-800/80 hover:border-cyan-500/40 p-5 transition-all duration-300 hover:-translate-y-1 shadow-lg"
              >
                <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 w-fit mb-3 text-cyan-400">
                  <Icon className="w-5 h-5" />
                </div>
                <h4 className="text-sm font-bold text-white mb-2">{pillar.title}</h4>
                <p className="text-xs text-slate-400 leading-relaxed">{pillar.desc}</p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
