import React, { useState } from 'react';
import { 
  ShieldAlert, 
  X, 
  CheckCircle, 
  Trash2, 
  Mail, 
  Download, 
  Eye, 
  Activity, 
  KeyRound, 
  Megaphone, 
  ThumbsUp, 
  Lock,
  LogOut,
  Sparkles
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';

export default function AdminDashboardModal({ isOpen, onClose }) {
  const { playClick, playSuccess, playAlert } = useAudio();
  const { 
    isAdminAuth, 
    loginAdmin, 
    logoutAdmin, 
    inquiries, 
    updateInquiryStatus, 
    deleteInquiry,
    guestbook,
    deleteGuestbookEntry,
    analytics,
    announcement,
    setAnnouncement
  } = useUser();

  const [enteredPin, setEnteredPin] = useState('');
  const [activeTab, setActiveTab] = useState('inquiries'); // 'inquiries' | 'guestbook' | 'broadcast' | 'analytics'
  const [newAnnouncement, setNewAnnouncement] = useState(announcement);

  if (!isOpen) return null;

  const handleLogin = (e) => {
    e.preventDefault();
    if (loginAdmin(enteredPin)) {
      setEnteredPin('');
    }
  };

  const handleUpdateAnnouncement = (e) => {
    e.preventDefault();
    playClick();
    setAnnouncement(newAnnouncement);
    playSuccess();
  };

  const exportLeadsJson = () => {
    playClick();
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(inquiries, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `pavan_portfolio_leads_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    playSuccess();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-[#091124] border border-purple-500/40 rounded-2xl shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#060c1c]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-950 border border-purple-500/40 text-purple-400">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Owner & Admin Control Center
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-500/30">
                  Pavan Gopal Patil
                </span>
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                CRM leads inbox, guestbook moderation, live announcement broadcaster & analytics
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isAdminAuth && (
              <button
                onClick={() => {
                  logoutAdmin();
                  onClose();
                }}
                className="px-3 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-xs font-mono text-purple-300 flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Lock Screen if not authenticated */}
        {!isAdminAuth ? (
          <div className="p-8 max-w-md mx-auto text-center space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-purple-950/60 border border-purple-500/40 mx-auto flex items-center justify-center text-purple-400">
              <Lock className="w-8 h-8 animate-pulse" />
            </div>

            <div>
              <h4 className="text-lg font-bold text-white">Owner PIN Authentication</h4>
              <p className="text-xs text-slate-400 font-mono mt-1">
                Enter your secure administrator PIN to manage incoming recruiter leads.
              </p>
              <div className="mt-2 p-2 rounded-lg bg-purple-950/40 border border-purple-500/20 text-[11px] font-mono text-purple-300">
                💡 Demo Testing PIN: <strong className="text-white">2028</strong>
              </div>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div className="relative">
                <KeyRound className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
                <input
                  type="password"
                  value={enteredPin}
                  onChange={(e) => setEnteredPin(e.target.value)}
                  placeholder="Enter PIN (2028)"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white font-mono text-center tracking-widest text-sm focus:border-purple-500 focus:outline-none"
                  autoFocus
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold font-mono text-xs shadow-lg shadow-purple-500/25"
              >
                Authenticate Access
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Admin Management Tabs */
          <div>
            <div className="flex border-b border-slate-800 bg-slate-950/60 px-6 pt-3 gap-4 text-xs font-mono">
              <button
                onClick={() => setActiveTab('inquiries')}
                className={`pb-3 font-semibold border-b-2 flex items-center gap-2 transition-all ${
                  activeTab === 'inquiries' ? 'border-purple-400 text-purple-300' : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Mail className="w-3.5 h-3.5" />
                <span>Leads & Inquiries ({inquiries.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('guestbook')}
                className={`pb-3 font-semibold border-b-2 flex items-center gap-2 transition-all ${
                  activeTab === 'guestbook' ? 'border-purple-400 text-purple-300' : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <ThumbsUp className="w-3.5 h-3.5" />
                <span>Guestbook Moderation ({guestbook.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('broadcast')}
                className={`pb-3 font-semibold border-b-2 flex items-center gap-2 transition-all ${
                  activeTab === 'broadcast' ? 'border-purple-400 text-purple-300' : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Megaphone className="w-3.5 h-3.5" />
                <span>Announcement Banner</span>
              </button>

              <button
                onClick={() => setActiveTab('analytics')}
                className={`pb-3 font-semibold border-b-2 flex items-center gap-2 transition-all ${
                  activeTab === 'analytics' ? 'border-purple-400 text-purple-300' : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                <span>Telemetry Analytics</span>
              </button>
            </div>

            <div className="p-6">
              
              {/* TAB 1: Leads & Inquiries */}
              {activeTab === 'inquiries' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-slate-400">
                      Incoming candidate inquiries from recruiters & visitors:
                    </span>
                    <button
                      onClick={exportLeadsJson}
                      className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 hover:border-purple-500 text-purple-300 text-xs font-mono flex items-center gap-1.5"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export Leads (JSON)</span>
                    </button>
                  </div>

                  {inquiries.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 font-mono text-xs">
                      No leads received yet.
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                      {inquiries.map((inq) => (
                        <div 
                          key={inq.id}
                          className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3"
                        >
                          <div className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-white">{inq.name}</span>
                              <span className="text-cyan-400 font-mono">@{inq.company}</span>
                              <span className="text-slate-400 text-[10px] font-mono">({inq.role})</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-mono text-slate-400">{inq.date}</span>
                              <select
                                value={inq.status}
                                onChange={(e) => updateInquiryStatus(inq.id, e.target.value)}
                                className="bg-slate-900 border border-slate-700 text-xs font-mono text-purple-300 rounded px-2 py-0.5 outline-none"
                              >
                                <option value="New">New</option>
                                <option value="In Review">In Review</option>
                                <option value="Contacted">Contacted</option>
                                <option value="Archived">Archived</option>
                              </select>
                              <button
                                onClick={() => deleteInquiry(inq.id)}
                                className="p-1 text-slate-500 hover:text-red-400 rounded"
                                title="Delete inquiry"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          <div className="text-xs text-slate-300 bg-slate-900/60 p-3 rounded-lg border border-slate-800/80">
                            {inq.message}
                          </div>

                          <div className="text-[11px] font-mono text-slate-400 flex items-center gap-4">
                            <span>Email: <a href={`mailto:${inq.email}`} className="text-cyan-400 hover:underline">{inq.email}</a></span>
                            <span className="text-emerald-400 font-semibold">Priority: {inq.priority}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* TAB 2: Guestbook Moderation */}
              {activeTab === 'guestbook' && (
                <div className="space-y-4">
                  <div className="text-xs font-mono text-slate-400">
                    Moderate testimonials and recommendations left by visitors:
                  </div>

                  <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
                    {guestbook.map((g) => (
                      <div key={g.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-start justify-between gap-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-xs">
                            <span className="font-bold text-white">{g.author}</span>
                            <span className="text-purple-400 font-mono text-[10px]">({g.role})</span>
                            <span className="text-slate-500 text-[10px]">• {g.date}</span>
                          </div>
                          <p className="text-xs text-slate-300">{g.comment}</p>
                          <span className="text-[10px] font-mono text-slate-400">Likes: {g.likes}</span>
                        </div>
                        <button
                          onClick={() => deleteGuestbookEntry(g.id)}
                          className="p-1.5 text-slate-500 hover:text-red-400 rounded bg-slate-900"
                          title="Remove endorsement"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: Announcement Broadcaster */}
              {activeTab === 'broadcast' && (
                <form onSubmit={handleUpdateAnnouncement} className="max-w-xl mx-auto space-y-4">
                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1 font-semibold">
                      Header Marquee Broadcast Banner:
                    </label>
                    <textarea
                      rows={3}
                      value={newAnnouncement}
                      onChange={(e) => setNewAnnouncement(e.target.value)}
                      placeholder="e.g. Currently open for Summer 2026/2027 ML Engineering Internships..."
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 p-3 text-xs text-white font-mono focus:border-purple-500 focus:outline-none"
                    />
                    <span className="text-[10px] font-mono text-slate-400 mt-1 block">
                      This text updates live at the top of the portfolio for every visitor and recruiter.
                    </span>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold font-mono text-xs"
                  >
                    Publish Live Broadcast Update
                  </button>
                </form>
              )}

              {/* TAB 4: Analytics */}
              {activeTab === 'analytics' && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className="text-xs font-mono text-slate-400 block">Total Portfolio Views</span>
                    <span className="text-3xl font-bold font-mono text-cyan-400 mt-2 block">{analytics.totalViews}</span>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className="text-xs font-mono text-slate-400 block">Resume Downloads</span>
                    <span className="text-3xl font-bold font-mono text-purple-400 mt-2 block">{analytics.resumeDownloads}</span>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className="text-xs font-mono text-slate-400 block">Interactive Demos Run</span>
                    <span className="text-3xl font-bold font-mono text-emerald-400 mt-2 block">{analytics.demoRuns}</span>
                  </div>
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
                    <span className="text-xs font-mono text-slate-400 block">Recruiter Inquiries</span>
                    <span className="text-3xl font-bold font-mono text-amber-400 mt-2 block">{analytics.recruiterInquiries}</span>
                  </div>
                </div>
              )}

            </div>
          </div>
        )}

      </div>
    </div>
  );
}
