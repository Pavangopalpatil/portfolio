import React, { useState } from 'react';
import { 
  X, 
  Sprout, 
  CheckCircle2, 
  Sliders, 
  Activity, 
  Sparkles, 
  Database, 
  Cpu, 
  Droplets, 
  Compass, 
  RefreshCw,
  Code
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';
import confetti from 'canvas-confetti';

export default function AgroSmartDemoModal({ isOpen, onClose }) {
  const { playClick, playSuccess } = useAudio();
  const { trackDemoRun } = useUser();

  const [soilType, setSoilType] = useState('black');
  const [nitrogen, setNitrogen] = useState(78);
  const [phosphorus, setPhosphorus] = useState(45);
  const [potassium, setPotassium] = useState(52);
  const [ph, setPh] = useState(6.8);
  const [rainfall, setRainfall] = useState(820);
  const [isInferring, setIsInferring] = useState(false);
  const [showCode, setShowCode] = useState(false);

  const [prediction, setPrediction] = useState({
    crop: "Cotton (Gossypium)",
    confidence: "94.8%",
    fertilizer: "Urea (46% N) + Single Superphosphate (SSP)",
    season: "Kharif (Monsoon)",
    yieldEstimate: "24-28 Quintals/Hectare",
    soilHealth: "Optimal Nitrogen & Balanced Organic Matter"
  });

  if (!isOpen) return null;

  const handleRunInference = () => {
    playClick();
    setIsInferring(true);
    trackDemoRun();

    setTimeout(() => {
      let recommendedCrop = "Cotton";
      let conf = (92.5 + Math.random() * 2.8).toFixed(1) + "%";
      let fert = "NPK 10:26:26 + Micronutrient Zinc";
      let season = "Kharif";
      let yieldEst = "22-26 Q/Ha";
      let health = "Favorable pH & Moisture retention";

      if (soilType === 'black') {
        recommendedCrop = nitrogen > 70 ? "Cotton (Bt Hybrid)" : "Soybean";
        fert = "Urea (46% N) + Diammonium Phosphate (DAP)";
        yieldEst = "26-30 Quintals/Hectare";
      } else if (soilType === 'alluvial') {
        recommendedCrop = rainfall > 800 ? "Rice (Paddy)" : "Wheat (Kalyan Sona)";
        fert = "Urea + Potassium Chloride (MOP)";
        yieldEst = "35-40 Quintals/Hectare";
      } else if (soilType === 'loamy') {
        recommendedCrop = "Maize (Corn) / Sugarcane";
        fert = "Compost Organic Manure + NPK 12:32:16";
        yieldEst = "30-34 Quintals/Hectare";
      } else if (soilType === 'red') {
        recommendedCrop = "Groundnut (Peanut) / Pulses";
        fert = "Gypsum + Phosphate solubilizing bacteria";
        yieldEst = "18-22 Quintals/Hectare";
      } else if (soilType === 'sandy') {
        recommendedCrop = "Pearl Millet (Bajra) / Watermelon";
        fert = "Drip fertigation with Soluble NPK";
        yieldEst = "15-18 Quintals/Hectare";
      } else {
        recommendedCrop = "Chickpea / Mustard";
        fert = "Ammonium Sulphate + Bio-fertilizer";
        yieldEst = "16-20 Quintals/Hectare";
      }

      setPrediction({
        crop: recommendedCrop,
        confidence: conf,
        fertilizer: fert,
        season: season,
        yieldEstimate: yieldEst,
        soilHealth: health
      });

      setIsInferring(false);
      playSuccess();
      try {
        confetti({
          particleCount: 40,
          spread: 60,
          origin: { y: 0.7 }
        });
      } catch {}
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#091124] border border-emerald-500/30 rounded-2xl shadow-2xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#060c1c]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-emerald-950 border border-emerald-500/40 text-emerald-400">
              <Sprout className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                AgroSmart ML Inference Engine
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                  92-95% Accuracy
                </span>
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Scikit-Learn Classifier & OpenCV Soil Analysis Sandbox
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowCode(!showCode)}
              className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-850 text-xs font-mono text-slate-300 hover:text-emerald-400 flex items-center gap-1.5"
            >
              <Code className="w-3.5 h-3.5" />
              <span>{showCode ? "Show Simulator" : "View Flask API"}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        {showCode ? (
          <div className="p-6 bg-[#040814] text-xs font-mono space-y-4">
            <div className="text-slate-400 flex items-center justify-between border-b border-slate-800 pb-2">
              <span>backend/api/agrosmart_service.py</span>
              <span className="text-emerald-400">Flask REST API Endpoint</span>
            </div>
            <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 overflow-x-auto leading-relaxed">
{`from flask import Flask, request, jsonify
import joblib
import numpy as np
import cv2

app = Flask(__name__)

# Load trained Scikit-learn Classifier (Trained with 95% accuracy)
crop_model = joblib.load('models/soil_crop_random_forest.pkl')
soil_classes = ['Black Soil', 'Alluvial Soil', 'Red Soil', 'Loamy Soil', 'Sandy Soil', 'Clay Soil']

@app.route('/api/predict_crop', methods=['POST'])
def predict_crop():
    data = request.json
    soil_type = data.get('soil_type')
    n = float(data.get('nitrogen', 50))
    p = float(data.get('phosphorus', 50))
    k = float(data.get('potassium', 50))
    ph = float(data.get('ph', 6.5))
    rainfall = float(data.get('rainfall', 800))
    
    # Feature vector representation
    features = np.array([[n, p, k, ph, rainfall]])
    prediction = crop_model.predict(features)[0]
    probabilities = crop_model.predict_proba(features)[0]
    confidence = float(np.max(probabilities)) * 100
    
    return jsonify({
        "status": "success",
        "recommended_crop": prediction,
        "confidence": f"{confidence:.1f}%",
        "timestamp": "2024-realtime"
    })`}
            </pre>
          </div>
        ) : (
          <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-6">
            
            {/* Input Controls: Sliders and Soil Selection */}
            <div className="md:col-span-7 space-y-5">
              
              {/* Soil Type Selector */}
              <div>
                <label className="text-xs font-mono text-slate-300 block mb-2 font-semibold">
                  1. Select Soil Classification (OpenCV Segmentation Class):
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'black', label: 'Black Soil', color: 'bg-stone-900 border-amber-900/60' },
                    { id: 'alluvial', label: 'Alluvial Soil', color: 'bg-amber-950/40 border-amber-700/40' },
                    { id: 'loamy', label: 'Loamy Soil', color: 'bg-emerald-950/40 border-emerald-700/40' },
                    { id: 'red', label: 'Red Soil', color: 'bg-red-950/40 border-red-700/40' },
                    { id: 'sandy', label: 'Sandy Soil', color: 'bg-yellow-950/40 border-yellow-700/40' },
                    { id: 'clay', label: 'Clay Soil', color: 'bg-slate-900 border-slate-700' }
                  ].map((s) => (
                    <button
                      key={s.id}
                      onClick={() => setSoilType(s.id)}
                      className={`p-2 rounded-lg text-xs font-mono border text-left transition-all ${
                        soilType === s.id
                          ? 'border-emerald-400 bg-emerald-950/60 text-emerald-300 font-bold shadow-md shadow-emerald-500/20'
                          : `${s.color} text-slate-400 hover:text-slate-200`
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Nutrients Sliders */}
              <div className="space-y-3 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-300">Nitrogen (N):</span>
                  <span className="text-emerald-400 font-bold">{nitrogen} mg/kg</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="140"
                  value={nitrogen}
                  onChange={(e) => setNitrogen(Number(e.target.value))}
                  className="w-full accent-emerald-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />

                <div className="flex justify-between text-xs font-mono pt-1">
                  <span className="text-slate-300">Phosphorus (P):</span>
                  <span className="text-emerald-400 font-bold">{phosphorus} mg/kg</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="100"
                  value={phosphorus}
                  onChange={(e) => setPhosphorus(Number(e.target.value))}
                  className="w-full accent-emerald-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />

                <div className="flex justify-between text-xs font-mono pt-1">
                  <span className="text-slate-300">Potassium (K):</span>
                  <span className="text-emerald-400 font-bold">{potassium} mg/kg</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="140"
                  value={potassium}
                  onChange={(e) => setPotassium(Number(e.target.value))}
                  className="w-full accent-emerald-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                />

                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div>
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-300">Soil pH:</span>
                      <span className="text-cyan-400 font-bold">{ph}</span>
                    </div>
                    <input
                      type="range"
                      min="4.0"
                      max="9.0"
                      step="0.1"
                      value={ph}
                      onChange={(e) => setPh(Number(e.target.value))}
                      className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-300">Rainfall:</span>
                      <span className="text-cyan-400 font-bold">{rainfall} mm</span>
                    </div>
                    <input
                      type="range"
                      min="300"
                      max="1400"
                      step="20"
                      value={rainfall}
                      onChange={(e) => setRainfall(Number(e.target.value))}
                      className="w-full accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
                    />
                  </div>
                </div>
              </div>

              {/* Trigger Prediction Button */}
              <button
                onClick={handleRunInference}
                disabled={isInferring}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/25 transition-all hover:scale-[1.01]"
              >
                {isInferring ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Executing Scikit-Learn Model...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Run AI Recommendation Inference</span>
                  </>
                )}
              </button>

            </div>

            {/* Right Column: Prediction Output Card */}
            <div className="md:col-span-5 bg-gradient-to-b from-[#0a1529] to-[#070e1c] border border-emerald-500/30 rounded-2xl p-5 space-y-4 flex flex-col justify-between">
              
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                    Model Inference Output
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-500/30 text-[11px] font-mono font-bold">
                    {prediction.confidence} Confidence
                  </span>
                </div>

                {/* Primary Recommendation */}
                <div>
                  <span className="text-xs text-slate-400 font-mono">Primary Suggested Crop:</span>
                  <div className="text-2xl font-extrabold text-white text-gradient-emerald mt-1">
                    {prediction.crop}
                  </div>
                </div>

                {/* Fertilizer Dosage */}
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[11px] font-mono text-cyan-400 block font-semibold">
                    Fertilizer Recommendation:
                  </span>
                  <p className="text-xs text-slate-200 mt-1">
                    {prediction.fertilizer}
                  </p>
                </div>

                {/* Season & Expected Yield */}
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Optimal Season</span>
                    <span className="text-slate-200 font-bold">{prediction.season}</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Est. Yield</span>
                    <span className="text-emerald-300 font-bold">{prediction.yieldEstimate}</span>
                  </div>
                </div>

                <div className="text-[11px] font-mono text-slate-400 p-2 rounded bg-slate-950 border border-slate-800">
                  <span className="text-emerald-400 font-bold">Soil Assessment: </span>
                  {prediction.soilHealth}
                </div>
              </div>

              {/* Deployed Stack Footnote */}
              <div className="pt-3 border-t border-slate-800 text-[10px] font-mono text-slate-400 flex items-center justify-between">
                <span>Stack: Flask + SQLite + Scikit</span>
                <span className="text-emerald-400">Deployed via Cloudflare</span>
              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
}
