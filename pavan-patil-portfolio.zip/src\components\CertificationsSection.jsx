import React from 'react';
import { 
  Award, 
  ExternalLink, 
  CheckCircle, 
  Sparkles, 
  BookOpen, 
  ShieldCheck,
  GraduationCap
} from 'lucide-react';
import { CERTIFICATIONS } from '../data/portfolioData';
import { useAudio } from '../context/AudioContext';

export default function CertificationsSection() {
  const { playClick, playHover } = useAudio();

  const colorStyles = {
    cyan: "border-cyan-500/30 text-cyan-400 bg-cyan-950/40",
    emerald: "border-emerald-500/30 text-emerald-400 bg-emerald-950/40",
    purple: "border-purple-500/30 text-purple-400 bg-purple-950/40",
    indigo: "border-indigo-500/30 text-indigo-400 bg-indigo-950/40",
    amber: "border-amber-500/30 text-amber-400 bg-amber-950/40"
  };

  return (
    <section id="certifications" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-950/50 border border-purple-500/30 text-xs font-mono text-purple-400">
            <Award className="w-3.5 h-3.5" />
            <span>CREDENTIALS & STANDARDS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Professional <span className="text-gradient-cyan">Certifications & Validations</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Verified mastery across algorithms, relational databases, Python system design, and applied machine learning.
          </p>
        </div>

        {/* Certifications Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {CERTIFICATIONS.map((cert) => {
            const badgeClass = colorStyles[cert.badgeColor] || colorStyles.cyan;

            return (
              <div
                key={cert.id}
                className="group relative rounded-2xl bg-gradient-to-br from-[#091124] to-[#070c1a] border border-slate-800 hover:border-cyan-500/40 p-6 shadow-xl transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between space-y-4"
              >
                <div className="space-y-4">
                  
                  {/* Issuer and Icon */}
                  <div className="flex items-center justify-between">
                    <span className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold border ${badgeClass}`}>
                      {cert.issuer}
                    </span>
                    <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 group-hover:text-cyan-400 transition-colors">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                  </div>

                  {/* Title */}
                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
                      {cert.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed font-sans">
                      {cert.description}
                    </p>
                  </div>

                  {/* Skills tags */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {cert.skills.map((skill, sIdx) => (
                      <span
                        key={sIdx}
                        className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-[10px] font-mono text-slate-300"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>

                </div>

                {/* Footer Link */}
                <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs font-mono">
                  <span className="text-emerald-400 flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5" />
                    Verified Credential
                  </span>
                  <a
                    href={cert.credentialUrl}
                    target="_blank"
                    rel="noreferrer"
                    onMouseEnter={playHover}
                    onClick={playClick}
                    className="text-slate-400 hover:text-cyan-400 flex items-center gap-1 transition-colors"
                  >
                    <span>View Platform</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
