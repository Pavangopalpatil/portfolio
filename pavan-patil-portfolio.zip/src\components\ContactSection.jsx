import React, { useState } from 'react';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Send, 
  Copy, 
  Check, 
  Sparkles, 
  MessageSquare, 
  ExternalLink, 
  Calendar 
} from 'lucide-react';
import { GithubIcon, LinkedinIcon } from './SocialIcons';
import { PERSONAL_INFO } from '../data/portfolioData';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';
import confetti from 'canvas-confetti';

export default function ContactSection() {
  const { playClick, playSuccess, playHover } = useAudio();
  const { submitInquiry } = useUser();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [copiedKey, setCopiedKey] = useState(null);
  const [isSent, setIsSent] = useState(false);

  const handleCopy = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    playSuccess();
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    playClick();

    submitInquiry({
      name,
      email,
      company: subject || 'General Inquiry',
      role: 'Direct Contact',
      message,
      priority: 'Standard'
    });

    setIsSent(true);
    playSuccess();

    try {
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.8 }
      });
    } catch {}

    setName('');
    setEmail('');
    setSubject('');
    setMessage('');

    setTimeout(() => setIsSent(false), 4000);
  };

  return (
    <section id="contact" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/50 border border-cyan-500/30 text-xs font-mono text-cyan-400">
            <Mail className="w-3.5 h-3.5" />
            <span>CONNECT WITH PAVAN</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Let's Discuss <span className="text-gradient-cyan">ML Engineering & Opportunities</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Interested in collaborating on computer vision pipelines, predictive systems, or recruiting for an engineering role? Reach out directly.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Direct Contact Information */}
          <div className="lg:col-span-5 space-y-5">
            
            <div className="rounded-2xl bg-gradient-to-br from-[#091124] to-[#070c1a] border border-cyan-500/30 p-6 shadow-xl space-y-6">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-cyan-400"></span>
                Direct Communication Channels
              </h3>

              {/* Email Card */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between group">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-cyan-950 text-cyan-400 border border-cyan-500/30">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 block uppercase">Email Address</span>
                    <a 
                      href={`mailto:${PERSONAL_INFO.email}`} 
                      className="text-xs sm:text-sm font-mono text-white hover:text-cyan-300 font-medium"
                    >
                      {PERSONAL_INFO.email}
                    </a>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(PERSONAL_INFO.email, 'email')}
                  className="p-2 text-slate-400 hover:text-cyan-300 rounded-lg hover:bg-slate-900 transition-colors"
                  title="Copy email address"
                >
                  {copiedKey === 'email' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* Phone Card */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between group">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-lg bg-emerald-950 text-emerald-400 border border-emerald-500/30">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[10px] font-mono text-slate-400 block uppercase">Direct Phone / WhatsApp</span>
                    <a 
                      href={`tel:${PERSONAL_INFO.phone}`} 
                      className="text-xs sm:text-sm font-mono text-white hover:text-emerald-300 font-medium"
                    >
                      {PERSONAL_INFO.phone}
                    </a>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(PERSONAL_INFO.phone, 'phone')}
                  className="p-2 text-slate-400 hover:text-emerald-300 rounded-lg hover:bg-slate-900 transition-colors"
                  title="Copy phone number"
                >
                  {copiedKey === 'phone' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              {/* LinkedIn & GitHub */}
              <div className="grid grid-cols-2 gap-3">
                <a
                  href={PERSONAL_INFO.linkedin}
                  target="_blank"
                  rel="noreferrer"
                  onMouseEnter={playHover}
                  onClick={playClick}
                  className="p-3.5 rounded-xl bg-blue-950/40 hover:bg-blue-900/50 border border-blue-500/30 text-blue-300 flex items-center justify-between transition-all"
                >
                  <div className="flex items-center gap-2 text-xs font-mono font-bold">
                    <LinkedinIcon className="w-4 h-4" />
                    <span>LinkedIn</span>
                  </div>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>

                <a
                  href={PERSONAL_INFO.github}
                  target="_blank"
                  rel="noreferrer"
                  onMouseEnter={playHover}
                  onClick={playClick}
                  className="p-3.5 rounded-xl bg-slate-900 hover:bg-slate-855 border border-slate-700 text-slate-200 flex items-center justify-between transition-all"
                >
                  <div className="flex items-center gap-2 text-xs font-mono font-bold">
                    <GithubIcon className="w-4 h-4" />
                    <span>GitHub</span>
                  </div>
                  <ExternalLink className="w-3 h-3 opacity-60" />
                </a>
              </div>

              {/* Location */}
              <div className="pt-2 text-xs font-mono text-slate-400 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Shirpur, Maharashtra, India (Open to Relocation & Remote)</span>
              </div>

            </div>

          </div>

          {/* Right Column: Direct Message Form */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl bg-gradient-to-br from-[#0c1429] to-[#080d1e] border border-cyan-500/30 p-7 shadow-2xl space-y-6">
              
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-base font-bold text-white">Send Direct Message</h3>
                <p className="text-xs text-slate-400 font-mono">
                  Messages are delivered directly into Pavan's authenticated owner dashboard
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">
                      Your Full Name:
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. John Doe"
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 p-3 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-mono text-slate-300 block mb-1">
                      Email Address:
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. john@example.com"
                      className="w-full rounded-xl bg-slate-950 border border-slate-800 p-3 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">
                    Subject / Company:
                  </label>
                  <input
                    type="text"
                    required
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="e.g. ML Engineering Internship / Project Collaboration"
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 p-3 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">
                    Message:
                  </label>
                  <textarea
                    rows={5}
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Describe your inquiry, project scope, or role specifications..."
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 p-3 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-xs font-mono flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/25 transition-all hover:scale-[1.01]"
                >
                  {isSent ? (
                    <>
                      <Check className="w-4 h-4 text-white" />
                      <span>Message Dispatched to Pavan's Inbox!</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Send Direct Message</span>
                    </>
                  )}
                </button>
              </form>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
