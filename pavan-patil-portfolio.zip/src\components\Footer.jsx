import React, { useState, useEffect } from 'react';
import { 
  ArrowUp, 
  Terminal, 
  ShieldAlert, 
  Briefcase, 
  UserCheck, 
  Mail, 
  Phone,
  Heart,
  Code
} from 'lucide-react';
import { GithubIcon, LinkedinIcon } from './SocialIcons';
import { PERSONAL_INFO } from '../data/portfolioData';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';

export default function Footer({ 
  onOpenTerminal, 
  onOpenRecruiterHub, 
  onOpenAdminModal 
}) {
  const { playClick, playHover } = useAudio();
  const { role } = useUser();
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const scrollToTop = () => {
    playClick();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="relative border-t border-slate-800/80 bg-[#040711] text-xs font-mono pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center justify-between">
          
          {/* Logo & Tagline */}
          <div className="md:col-span-5 space-y-2">
            <div className="flex items-center gap-2">
              <span className="font-bold text-white text-base">
                {PERSONAL_INFO.name}
              </span>
              <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-500/30 text-[10px]">
                ML Engineer
              </span>
            </div>
            <p className="text-slate-400 text-xs font-sans leading-relaxed">
              B.Tech Computer Science & Engineering (Data Science) @ R.C. Patel Institute of Technology.
              Crafting high-accuracy Computer Vision & Predictive ML applications.
            </p>
          </div>

          {/* Quick Access Portals */}
          <div className="md:col-span-4 flex flex-wrap gap-2 items-center">
            <button
              onClick={() => {
                playClick();
                onOpenRecruiterHub();
              }}
              onMouseEnter={playHover}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/40 text-cyan-300 text-xs flex items-center gap-1.5"
            >
              <Briefcase className="w-3.5 h-3.5" />
              <span>Recruiter Hub</span>
            </button>

            <button
              onClick={() => {
                playClick();
                onOpenAdminModal();
              }}
              onMouseEnter={playHover}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-purple-500/40 text-purple-300 text-xs flex items-center gap-1.5"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Admin Panel</span>
            </button>

            <button
              onClick={() => {
                playClick();
                onOpenTerminal();
              }}
              onMouseEnter={playHover}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-1.5"
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>PavanOS CLI</span>
            </button>
          </div>

          {/* System Telemetry & Back to Top */}
          <div className="md:col-span-3 flex items-center justify-start md:justify-end gap-3">
            <div className="text-right">
              <div className="text-cyan-400 font-bold">{timeStr} IST</div>
              <div className="text-[10px] text-slate-500 flex items-center gap-1 justify-end">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>SYSTEM ONLINE</span>
              </div>
            </div>

            <button
              onClick={scrollToTop}
              onMouseEnter={playHover}
              className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-cyan-400 hover:text-white transition-colors"
              title="Back to Top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>

        </div>

        {/* Bottom Strip */}
        <div className="pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-3">
          <div>
            © {new Date().getFullYear()} Pavan Gopal Patil. Built for High-Impact Machine Learning & AI Engineering.
          </div>
          <div className="flex items-center gap-4">
            <a href={PERSONAL_INFO.github} target="_blank" rel="noreferrer" className="hover:text-cyan-400">
              GitHub
            </a>
            <a href={PERSONAL_INFO.linkedin} target="_blank" rel="noreferrer" className="hover:text-cyan-400">
              LinkedIn
            </a>
            <a href={`mailto:${PERSONAL_INFO.email}`} className="hover:text-cyan-400">
              Email
            </a>
          </div>
        </div>

      </div>
    </footer>
  );
}
