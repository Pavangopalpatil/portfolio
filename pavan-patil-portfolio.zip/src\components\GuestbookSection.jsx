import React, { useState } from 'react';
import { 
  MessageSquare, 
  Heart, 
  Send, 
  Sparkles, 
  CheckCircle2, 
  User, 
  Building,
  ThumbsUp
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';
import confetti from 'canvas-confetti';

export default function GuestbookSection() {
  const { playClick, playSuccess, playHover } = useAudio();
  const { guestbook, addGuestbookEntry, likeGuestbookEntry } = useUser();

  const [author, setAuthor] = useState('');
  const [role, setRole] = useState('');
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!comment.trim()) return;

    playClick();
    setIsSubmitting(true);

    setTimeout(() => {
      addGuestbookEntry({
        author: author.trim() || 'Software Engineer',
        role: role.trim() || 'Tech Reviewer',
        comment: comment.trim()
      });

      setAuthor('');
      setRole('');
      setComment('');
      setIsSubmitting(false);
      playSuccess();

      try {
        confetti({
          particleCount: 40,
          spread: 60,
          origin: { y: 0.8 }
        });
      } catch {}
    }, 400);
  };

  return (
    <section id="guestbook" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/50 border border-cyan-500/30 text-xs font-mono text-cyan-400">
            <MessageSquare className="w-3.5 h-3.5" />
            <span>COMMUNITY & PEER ENDORSEMENTS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Guestbook & <span className="text-gradient-cyan">Recommendations</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Leave feedback, endorse Pavan's machine learning engineering work, or connect with fellow technologists.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left: Testimonials Feed */}
          <div className="lg:col-span-7 space-y-4">
            <div className="grid grid-cols-1 gap-4">
              {guestbook.map((entry) => (
                <div
                  key={entry.id}
                  className="rounded-2xl bg-gradient-to-br from-[#091124] to-[#070c1a] border border-slate-800 hover:border-cyan-500/40 p-5 shadow-xl transition-all duration-300 space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center font-mono font-bold text-slate-950 text-xs shadow-md shadow-cyan-500/20">
                        {entry.avatar}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">{entry.author}</h4>
                        <p className="text-[11px] font-mono text-cyan-400">{entry.role}</p>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500">{entry.date}</span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
                    "{entry.comment}"
                  </p>

                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                    <button
                      onClick={() => {
                        playClick();
                        likeGuestbookEntry(entry.id);
                      }}
                      onMouseEnter={playHover}
                      className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900/80 hover:bg-slate-850 text-slate-400 hover:text-cyan-400 text-xs font-mono border border-slate-800 transition-colors"
                    >
                      <ThumbsUp className="w-3 h-3 text-cyan-400" />
                      <span>{entry.likes} Helpful</span>
                    </button>
                    <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" />
                      Verified Entry
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Leave Endorsement Form */}
          <div className="lg:col-span-5">
            <div className="rounded-2xl bg-gradient-to-br from-[#0c1429] to-[#080d1e] border border-cyan-500/30 p-6 shadow-2xl space-y-5 sticky top-24">
              
              <div className="flex items-center gap-3 pb-3 border-b border-slate-800">
                <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-400">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Sign the Guestbook</h3>
                  <p className="text-xs text-slate-400 font-mono">Instant live submission</p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">
                    Your Name:
                  </label>
                  <input
                    type="text"
                    required
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    placeholder="e.g. Jordan Lee"
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">
                    Your Role / Title & Company:
                  </label>
                  <input
                    type="text"
                    required
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    placeholder="e.g. Senior ML Engineer @ Tech Co."
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">
                    Your Message / Recommendation:
                  </label>
                  <textarea
                    rows={4}
                    required
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Share feedback on Pavan's models, live interactive demos, or engineering work..."
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs font-mono flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all hover:scale-[1.01]"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? "Posting..." : "Post Recommendation"}</span>
                </button>
              </form>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
