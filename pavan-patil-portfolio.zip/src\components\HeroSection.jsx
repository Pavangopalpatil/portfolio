import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Terminal, 
  ArrowRight, 
  Eye, 
  Cpu, 
  Mail, 
  Phone, 
  Check, 
  Copy, 
  FileCheck, 
  BrainCircuit, 
  Sliders, 
  ExternalLink 
} from 'lucide-react';
import { GithubIcon, LinkedinIcon } from './SocialIcons';
import { PERSONAL_INFO } from '../data/portfolioData';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';

export default function HeroSection({ 
  onOpenAgroDemo, 
  onOpenProctorDemo, 
  onOpenTerminal,
  onOpenRecruiterHub 
}) {
  const { playClick, playHover, playSuccess } = useAudio();
  const { role } = useUser();
  const [copiedType, setCopiedType] = useState(null);

  const rotatingTitles = [
    "Machine Learning & AI Engineer",
    "Computer Vision & Deep Learning Specialist",
    "End-to-End Predictive Systems Architect",
    "Python, Flask & OpenCV Developer"
  ];

  const [titleIndex, setTitleIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setTitleIndex((prev) => (prev + 1) % rotatingTitles.length);
    }, 3200);
    return () => clearInterval(interval);
  }, []);

  const copyToClipboard = (text, type) => {
    navigator.clipboard.writeText(text);
    setCopiedType(type);
    playSuccess();
    setTimeout(() => setCopiedType(null), 2500);
  };

  return (
    <section className="relative pt-12 pb-24 md:pt-20 md:pb-32 overflow-hidden">
      {/* Glow Orbs */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-cyan-600/20 via-indigo-600/15 to-purple-600/20 blur-[130px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Hero Text & CTAs */}
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            
            {/* Top Status Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-cyan-500/30 text-xs font-mono text-cyan-300 shadow-lg shadow-cyan-950/40">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400"></span>
              </span>
              <span>B.Tech CSE (Data Science) • 92–95% ML Accuracy</span>
            </div>

            {/* Main Heading */}
            <div className="space-y-2">
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-white">
                Hi, I'm{' '}
                <span className="text-gradient-cyan block sm:inline">
                  {PERSONAL_INFO.name}
                </span>
              </h1>
              <div className="h-10 sm:h-12 flex items-center justify-center lg:justify-start">
                <p className="text-xl sm:text-2xl font-mono text-cyan-400 font-medium">
                  &gt; {rotatingTitles[titleIndex]}
                  <span className="inline-block w-2.5 h-5 ml-1 bg-cyan-400 animate-pulse align-middle"></span>
                </p>
              </div>
            </div>

            {/* Summary description from Resume */}
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
              {PERSONAL_INFO.summary}
            </p>

            {/* Quick Contact & Verified Badge Strip */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3 pt-2 text-xs font-mono">
              <button
                onClick={() => copyToClipboard(PERSONAL_INFO.email, 'email')}
                onMouseEnter={playHover}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-cyan-300 transition-all"
                title="Click to copy email address"
              >
                {copiedType === 'email' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Mail className="w-3.5 h-3.5 text-cyan-400" />}
                <span>{PERSONAL_INFO.email}</span>
                {copiedType === 'email' ? <span className="text-emerald-400 font-bold ml-1">Copied!</span> : <Copy className="w-3 h-3 text-slate-500" />}
              </button>

              <button
                onClick={() => copyToClipboard(PERSONAL_INFO.phone, 'phone')}
                onMouseEnter={playHover}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-cyan-300 transition-all"
                title="Click to copy phone number"
              >
                {copiedType === 'phone' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Phone className="w-3.5 h-3.5 text-emerald-400" />}
                <span>{PERSONAL_INFO.phone}</span>
                {copiedType === 'phone' ? <span className="text-emerald-400 font-bold ml-1">Copied!</span> : <Copy className="w-3 h-3 text-slate-500" />}
              </button>

              <a
                href={PERSONAL_INFO.linkedin}
                target="_blank"
                rel="noreferrer"
                onMouseEnter={playHover}
                onClick={playClick}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-950/40 hover:bg-blue-900/50 border border-blue-500/30 text-blue-300 transition-all"
              >
                <LinkedinIcon className="w-3.5 h-3.5" />
                <span>LinkedIn</span>
                <ExternalLink className="w-3 h-3 ml-0.5 opacity-60" />
              </a>

              <a
                href={PERSONAL_INFO.github}
                target="_blank"
                rel="noreferrer"
                onMouseEnter={playHover}
                onClick={playClick}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white transition-all"
              >
                <GithubIcon className="w-3.5 h-3.5" />
                <span>GitHub</span>
                <ExternalLink className="w-3 h-3 ml-0.5 opacity-60" />
              </a>
            </div>

            {/* Call To Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-4">
              <a
                href="#projects"
                onMouseEnter={playHover}
                onClick={playClick}
                className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-cyan-500/25 flex items-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Sparkles className="w-4 h-4" />
                <span>Explore Live AI Projects</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </a>

              <button
                onClick={() => {
                  playClick();
                  onOpenRecruiterHub();
                }}
                onMouseEnter={playHover}
                className="px-5 py-3.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-cyan-500/40 hover:border-cyan-400 text-cyan-300 font-semibold text-sm flex items-center gap-2 transition-all hover:scale-[1.02]"
              >
                <FileCheck className="w-4 h-4 text-cyan-400" />
                <span>Recruiter Hub & ATS Match</span>
              </button>

              <button
                onClick={() => {
                  playClick();
                  onOpenTerminal();
                }}
                onMouseEnter={playHover}
                className="px-4 py-3.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white font-mono text-xs flex items-center gap-2"
                title="Launch PavanOS Terminal"
              >
                <Terminal className="w-4 h-4 text-cyan-400" />
                <span>CLI Terminal</span>
              </button>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-6 border-t border-slate-800/80">
              <div className="bg-slate-900/40 p-3 rounded-xl border border-slate-800/80">
                <div className="text-2xl font-bold font-mono text-cyan-400">92-95%</div>
                <div className="text-xs text-slate-400 font-medium">Model Accuracy</div>
              </div>
              <div className="bg-slate-900/40 p-3 rounded-xl border border-slate-800/80">
                <div className="text-2xl font-bold font-mono text-purple-400">95%</div>
                <div className="text-xs text-slate-400 font-medium">YOLO Exam Vision</div>
              </div>
              <div className="bg-slate-900/40 p-3 rounded-xl border border-slate-800/80">
                <div className="text-2xl font-bold font-mono text-emerald-400">5+</div>
                <div className="text-xs text-slate-400 font-medium">Certifications</div>
              </div>
              <div className="bg-slate-900/40 p-3 rounded-xl border border-slate-800/80">
                <div className="text-2xl font-bold font-mono text-amber-400">7.0 / 10</div>
                <div className="text-xs text-slate-400 font-medium">B.Tech CGPA</div>
              </div>
            </div>

          </div>

          {/* Right Column: Interactive 3D Holographic AI Telemetry Card */}
          <div className="lg:col-span-5">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              
              {/* Outer decorative neon frame */}
              <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-cyan-500/30 via-purple-500/30 to-blue-500/30 blur-lg opacity-70 group-hover:opacity-100 transition duration-1000"></div>

              {/* Main Interactive Hologram Card */}
              <div className="relative rounded-2xl bg-[#091124] border border-cyan-500/30 p-6 shadow-2xl backdrop-blur-xl">
                
                {/* Header bar */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <div className="h-3 w-3 rounded-full bg-red-500/80"></div>
                    <div className="h-3 w-3 rounded-full bg-amber-500/80"></div>
                    <div className="h-3 w-3 rounded-full bg-emerald-500/80"></div>
                    <span className="font-mono text-xs text-slate-400 ml-2">pavan_engine.py</span>
                  </div>
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/30">
                    LIVE ML CORE
                  </span>
                </div>

                {/* Simulated Computer Vision Visualizer */}
                <div className="my-5 relative rounded-xl bg-[#050914] border border-slate-800 p-4 overflow-hidden">
                  <div className="flex items-center justify-between mb-3 text-xs font-mono">
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <BrainCircuit className="w-3.5 h-3.5 text-cyan-400" />
                      Active Neural Pipeline
                    </span>
                    <span className="text-emerald-400 font-bold animate-pulse">● 30 FPS Stream</span>
                  </div>

                  {/* Visual bounding boxes simulation */}
                  <div className="relative h-44 bg-gradient-to-b from-slate-950 to-slate-900 rounded-lg border border-slate-800 flex items-center justify-center overflow-hidden">
                    {/* Simulated grid */}
                    <div className="absolute inset-0 cyber-grid opacity-30"></div>

                    {/* Scanline effect */}
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/10 to-transparent h-12 w-full animate-scanline pointer-events-none"></div>

                    {/* Face Detection Bounding Box */}
                    <div className="relative border-2 border-cyan-400 bg-cyan-500/10 rounded px-4 py-3 shadow-lg shadow-cyan-500/20 text-center animate-float">
                      <div className="absolute -top-3 left-2 bg-cyan-500 text-slate-950 text-[10px] font-mono font-bold px-1.5 rounded">
                        CONF: 0.952 [FACE]
                      </div>
                      <Eye className="w-8 h-8 text-cyan-300 mx-auto my-1" />
                      <div className="text-[11px] font-mono text-cyan-200">
                        Status: Focused
                      </div>
                      <div className="text-[9px] font-mono text-slate-400">
                        Haar + YOLOv3-Tiny
                      </div>
                    </div>

                    {/* Secondary detection box */}
                    <div className="absolute bottom-2 right-2 border border-emerald-400/80 bg-emerald-500/10 rounded px-2 py-1 text-[9px] font-mono text-emerald-300">
                      Mobile: Negative (Safe)
                    </div>
                  </div>

                  {/* Interactive Quick Launchers directly in card */}
                  <div className="mt-4 grid grid-cols-2 gap-2.5">
                    <button
                      onClick={() => {
                        playClick();
                        onOpenAgroDemo();
                      }}
                      onMouseEnter={playHover}
                      className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg bg-emerald-950/40 hover:bg-emerald-900/50 border border-emerald-500/40 text-emerald-300 text-xs font-semibold transition-all hover:scale-[1.02]"
                    >
                      <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                      <span>AgroSmart Demo</span>
                    </button>

                    <button
                      onClick={() => {
                        playClick();
                        onOpenProctorDemo();
                      }}
                      onMouseEnter={playHover}
                      className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/40 text-cyan-300 text-xs font-semibold transition-all hover:scale-[1.02]"
                    >
                      <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Exam Proctor Sandbox</span>
                    </button>
                  </div>
                </div>

                {/* Resume Fast Summary footer */}
                <div className="pt-2 text-[11px] font-mono text-slate-400 flex items-center justify-between border-t border-slate-800/80">
                  <span>R.C. Patel Institute of Tech, Shirpur</span>
                  <span className="text-cyan-400 font-bold">Class of 2028</span>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
