import React, { useState, useEffect } from 'react';
import { 
  Terminal, 
  Volume2, 
  VolumeX, 
  UserCheck, 
  Briefcase, 
  ShieldAlert, 
  FileText, 
  Menu, 
  X,
  Sparkles,
  ChevronDown
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';
import { PERSONAL_INFO } from '../data/portfolioData';

export default function Navbar({ 
  onOpenTerminal, 
  onOpenResume, 
  onOpenAdminModal,
  onOpenRecruiterHub 
}) {
  const { soundEnabled, toggleSound, playClick, playHover } = useAudio();
  const { role, switchToGuest, announcement } = useUser();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [roleDropdownOpen, setRoleDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: 'About', href: '#about' },
    { label: 'Skills', href: '#skills' },
    { label: 'Projects', href: '#projects' },
    { label: 'Certifications', href: '#certifications' },
    { label: 'Guestbook', href: '#guestbook' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <>
      {/* Top Live Announcement Bar (Editable in Admin Mode) */}
      {announcement && (
        <div className="relative z-50 bg-gradient-to-r from-cyan-950/80 via-slate-900/90 to-purple-950/80 border-b border-cyan-500/20 text-xs py-1.5 px-4 text-center text-cyan-200 flex items-center justify-center gap-2 overflow-hidden">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
          </span>
          <span className="font-medium tracking-wide truncate max-w-4xl">{announcement}</span>
        </div>
      )}

      {/* Main Sticky Navbar */}
      <nav 
        className={`sticky top-0 z-40 transition-all duration-300 ${
          scrolled 
            ? 'bg-[#060b18]/85 backdrop-blur-md border-b border-cyan-500/15 shadow-xl shadow-cyan-950/20 py-3' 
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <a 
              href="#" 
              onMouseEnter={playHover}
              onClick={playClick}
              className="flex items-center gap-3 group"
            >
              <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-cyan-500 to-purple-600 p-[1px] shadow-lg shadow-cyan-500/25 group-hover:shadow-cyan-500/40 transition-all">
                <div className="h-full w-full bg-[#070d1e] rounded-[11px] flex items-center justify-center">
                  <span className="font-mono text-cyan-400 font-bold text-sm tracking-tighter">
                    &lt;PG/&gt;
                  </span>
                </div>
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-base tracking-tight text-white group-hover:text-cyan-400 transition-colors">
                  {PERSONAL_INFO.name}
                </span>
                <span className="text-[11px] text-slate-400 font-mono tracking-wider flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  ML & AI Engineer
                </span>
              </div>
            </a>

            {/* Desktop Navigation Links */}
            <div className="hidden lg:flex items-center gap-1 bg-slate-900/60 p-1 rounded-full border border-slate-800 backdrop-blur-md">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onMouseEnter={playHover}
                  onClick={playClick}
                  className="px-3.5 py-1.5 text-xs font-medium text-slate-300 hover:text-cyan-300 hover:bg-slate-800/80 rounded-full transition-all"
                >
                  {link.label}
                </a>
              ))}
            </div>

            {/* Right Action Controls: Role Switcher, Audio, Terminal, Resume */}
            <div className="hidden sm:flex items-center gap-2.5">
              {/* Role Indicator / Mode Selector */}
              <div className="relative">
                <button
                  onClick={() => {
                    playClick();
                    setRoleDropdownOpen(!roleDropdownOpen);
                  }}
                  onMouseEnter={playHover}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                    role === 'admin'
                      ? 'bg-purple-950/60 border-purple-500/50 text-purple-300 shadow-sm shadow-purple-500/30'
                      : role === 'recruiter'
                      ? 'bg-cyan-950/60 border-cyan-500/50 text-cyan-300 shadow-sm shadow-cyan-500/30'
                      : 'bg-slate-900/80 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                  title="Switch User Role / View Management Dashboard"
                >
                  {role === 'admin' && <ShieldAlert className="w-3.5 h-3.5 text-purple-400" />}
                  {role === 'recruiter' && <Briefcase className="w-3.5 h-3.5 text-cyan-400" />}
                  {role === 'guest' && <UserCheck className="w-3.5 h-3.5 text-emerald-400" />}
                  <span className="capitalize">{role === 'guest' ? 'Visitor Mode' : `${role} Mode`}</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {/* Role Switcher Menu */}
                {roleDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 rounded-xl bg-[#091124] border border-cyan-500/30 shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                    <div className="px-2 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-800/80">
                      User Management
                    </div>

                    <button
                      onClick={() => {
                        switchToGuest();
                        setRoleDropdownOpen(false);
                      }}
                      className={`w-full flex items-center gap-2.5 px-2.5 py-2 mt-1 rounded-lg text-xs text-left transition-colors ${
                        role === 'guest' ? 'bg-cyan-950/50 text-cyan-300' : 'text-slate-300 hover:bg-slate-800/50'
                      }`}
                    >
                      <UserCheck className="w-4 h-4 text-emerald-400" />
                      <div>
                        <div className="font-medium">Visitor / Guest</div>
                        <div className="text-[10px] text-slate-400">Interactive live AI demos</div>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        setRoleDropdownOpen(false);
                        onOpenRecruiterHub();
                      }}
                      className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs text-left transition-colors ${
                        role === 'recruiter' ? 'bg-cyan-950/50 text-cyan-300' : 'text-slate-300 hover:bg-slate-800/50'
                      }`}
                    >
                      <Briefcase className="w-4 h-4 text-cyan-400" />
                      <div>
                        <div className="font-medium">Recruiter Hub</div>
                        <div className="text-[10px] text-slate-400">ATS matcher & hire tool</div>
                      </div>
                    </button>

                    <button
                      onClick={() => {
                        setRoleDropdownOpen(false);
                        onOpenAdminModal();
                      }}
                      className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs text-left transition-colors ${
                        role === 'admin' ? 'bg-purple-950/50 text-purple-300' : 'text-slate-300 hover:bg-slate-800/50'
                      }`}
                    >
                      <ShieldAlert className="w-4 h-4 text-purple-400" />
                      <div>
                        <div className="font-medium">Admin Dashboard</div>
                        <div className="text-[10px] text-slate-400">CRM leads & moderation</div>
                      </div>
                    </button>
                  </div>
                )}
              </div>

              {/* Sound Toggle */}
              <button
                onClick={toggleSound}
                onMouseEnter={playHover}
                className={`p-2 rounded-lg border transition-all ${
                  soundEnabled 
                    ? 'bg-cyan-950/40 border-cyan-500/40 text-cyan-300 shadow-sm shadow-cyan-500/20' 
                    : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
                title={soundEnabled ? 'SFX Audio Enabled (Click to Mute)' : 'SFX Audio Muted (Click to Enable)'}
                aria-label="Toggle sound effects"
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>

              {/* Terminal Button */}
              <button
                onClick={() => {
                  playClick();
                  onOpenTerminal();
                }}
                onMouseEnter={playHover}
                className="hidden md:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 text-xs font-mono text-cyan-400 hover:border-cyan-500/50 transition-all"
                title="Open Interactive PavanOS ML Terminal"
              >
                <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                <span>CLI</span>
              </button>

              {/* View Resume Button */}
              <button
                onClick={() => {
                  playClick();
                  onOpenResume();
                }}
                onMouseEnter={playHover}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-medium text-xs shadow-md shadow-cyan-500/25 transition-all"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Resume</span>
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="flex sm:hidden items-center gap-2">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="sm:hidden bg-[#070d1e] border-b border-cyan-500/20 px-4 pt-3 pb-6 mt-2 space-y-3">
            <div className="grid grid-cols-2 gap-2 pb-3 border-b border-slate-800">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2 rounded-lg bg-slate-900/60 text-xs font-medium text-slate-300 hover:text-cyan-300"
                >
                  {link.label}
                </a>
              ))}
            </div>

            <div className="flex flex-col gap-2 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-400 font-mono">Current User Role:</span>
                <span className="text-xs font-bold text-cyan-400 capitalize">{role}</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenRecruiterHub();
                  }}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 text-xs font-medium"
                >
                  <Briefcase className="w-3.5 h-3.5" /> Recruiter Hub
                </button>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenAdminModal();
                  }}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-purple-950/60 border border-purple-500/40 text-purple-300 text-xs font-medium"
                >
                  <ShieldAlert className="w-3.5 h-3.5" /> Admin Panel
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenTerminal();
                  }}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-slate-900 border border-slate-800 text-cyan-400 text-xs font-mono"
                >
                  <Terminal className="w-3.5 h-3.5" /> PavanOS CLI
                </button>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenResume();
                  }}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg bg-cyan-500 text-slate-950 text-xs font-bold"
                >
                  <FileText className="w-3.5 h-3.5" /> Resume
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>
    </>
  );
}
