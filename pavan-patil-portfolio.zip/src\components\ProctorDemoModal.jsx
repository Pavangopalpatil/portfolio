import React, { useState, useEffect, useRef } from 'react';
import { 
  X, 
  Eye, 
  AlertTriangle, 
  ShieldCheck, 
  FileDown, 
  Smartphone, 
  Users, 
  UserMinus, 
  Activity, 
  Camera, 
  CameraOff, 
  Play, 
  Pause, 
  CheckCircle,
  Clock,
  Printer
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';
import confetti from 'canvas-confetti';

export default function ProctorDemoModal({ isOpen, onClose }) {
  const { playClick, playHover, playAlert, playSuccess } = useAudio();
  const { trackDemoRun } = useUser();

  const [useWebcam, setUseWebcam] = useState(false);
  const [isRunning, setIsRunning] = useState(true);
  const [phoneDetected, setPhoneDetected] = useState(false);
  const [multiplePersons, setMultiplePersons] = useState(false);
  const [faceAbsent, setFaceAbsent] = useState(false);
  const [gazeDirection, setGazeDirection] = useState('Center (Normal)');
  const [showReportPreview, setShowReportPreview] = useState(false);

  const videoRef = useRef(null);

  // Violations log list
  const [violations, setViolations] = useState([
    { id: 1, time: '10:02:14 AM', type: 'Session Initialized', severity: 'Info', details: 'Webcam connected, YOLOv3-Tiny loaded' }
  ]);

  useEffect(() => {
    if (isOpen) {
      trackDemoRun();
    }
  }, [isOpen]);

  // Tab switch listener
  useEffect(() => {
    if (!isOpen) return;

    const handleVisibilityChange = () => {
      if (document.hidden) {
        logViolation('Tab Switch Detected', 'Critical', 'Student switched browser tab / window unfocused');
        playAlert();
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [isOpen]);

  // Webcam stream handler
  useEffect(() => {
    if (useWebcam && isOpen) {
      navigator.mediaDevices?.getUserMedia({ video: true })
        .then((stream) => {
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        })
        .catch(() => {
          setUseWebcam(false);
        });
    } else {
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = videoRef.current.srcObject.getTracks();
        tracks.forEach(track => track.stop());
      }
    }

    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = videoRef.current.srcObject.getTracks();
        tracks.forEach(track => track.stop());
      }
    };
  }, [useWebcam, isOpen]);

  if (!isOpen) return null;

  const logViolation = (type, severity, details) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString();
    setViolations(prev => [
      { id: Date.now(), time: timeStr, type, severity, details },
      ...prev.slice(0, 19)
    ]);
  };

  const togglePhone = () => {
    playClick();
    const next = !phoneDetected;
    setPhoneDetected(next);
    if (next) {
      playAlert();
      logViolation('Mobile Device Detected', 'Critical', 'YOLOv3-Tiny detected mobile phone (Conf: 95.4%)');
    }
  };

  const toggleMultiple = () => {
    playClick();
    const next = !multiplePersons;
    setMultiplePersons(next);
    if (next) {
      playAlert();
      logViolation('Multiple Persons In Frame', 'High', 'Haar Cascade detected 2 distinct facial profiles');
    }
  };

  const toggleFaceAbsent = () => {
    playClick();
    const next = !faceAbsent;
    setFaceAbsent(next);
    if (next) {
      playAlert();
      logViolation('Candidate Absence', 'Critical', 'Zero facial landmarks detected in viewport');
    }
  };

  const simulateTabSwitch = () => {
    playClick();
    playAlert();
    logViolation('Simulated Tab Switch', 'Critical', 'Browser API detected blur event from examination window');
  };

  const generateReport = () => {
    playClick();
    playSuccess();
    setShowReportPreview(true);
    try {
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {}
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-5xl bg-[#091124] border border-cyan-500/30 rounded-2xl shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#060c1c]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <Eye className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                AI Online Exam Proctoring Sandbox
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                  95% Detection Accuracy
                </span>
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                OpenCV, YOLOv3-Tiny, Haar Cascade Classifiers & ReportLab PDF Generator
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                playClick();
                setUseWebcam(!useWebcam);
              }}
              className="px-3 py-1 rounded-lg bg-slate-900 border border-slate-700 text-xs font-mono text-cyan-300 hover:text-white flex items-center gap-1.5"
            >
              {useWebcam ? <CameraOff className="w-3.5 h-3.5" /> : <Camera className="w-3.5 h-3.5" />}
              <span>{useWebcam ? "Use Synthetic Stream" : "Use Real Camera"}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Content */}
        {showReportPreview ? (
          /* ReportLab PDF Report Preview */
          <div className="p-6 bg-[#040814] space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h4 className="text-base font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  Generated ReportLab Proctoring Audit Certificate
                </h4>
                <p className="text-xs text-slate-400 font-mono">Generated via Python ReportLab Engine & Flask API</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-mono text-white flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Report</span>
                </button>
                <button
                  onClick={() => setShowReportPreview(false)}
                  className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 text-xs font-bold font-mono"
                >
                  Back to Sandbox
                </button>
              </div>
            </div>

            {/* Printable Certificate Layout */}
            <div className="bg-white text-slate-900 p-8 rounded-xl shadow-2xl font-mono text-xs max-w-3xl mx-auto border-4 border-slate-800">
              <div className="flex justify-between items-start border-b-2 border-slate-900 pb-4">
                <div>
                  <h2 className="text-xl font-bold tracking-tight text-slate-950 font-sans">
                    ONLINE EXAMINATION INTEGRITY AUDIT REPORT
                  </h2>
                  <p className="text-[11px] text-slate-600">
                    Engineered by Pavan Gopal Patil • Automated ReportLab Generation
                  </p>
                </div>
                <div className="text-right">
                  <span className="inline-block bg-slate-900 text-white font-bold px-2.5 py-1 text-[11px] rounded">
                    INTEGRITY RATING: {violations.length <= 2 ? "98.5% [APPROVED]" : "88.2% [FLAGGED FOR REVIEW]"}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 my-4 py-3 border-b border-slate-300">
                <div>
                  <p><span className="font-bold">Candidate Session ID:</span> EXAM-2026-8819</p>
                  <p><span className="font-bold">Candidate Name:</span> Verified Examinee</p>
                  <p><span className="font-bold">Course / Exam:</span> CS-DS-ML-502 Final Evaluation</p>
                </div>
                <div>
                  <p><span className="font-bold">Proctoring Backend:</span> Flask + OpenCV + YOLOv3-Tiny</p>
                  <p><span className="font-bold">Database Storage:</span> SQLite Persistent Ledger</p>
                  <p><span className="font-bold">Audit Timestamp:</span> {new Date().toLocaleString()}</p>
                </div>
              </div>

              <div className="my-4">
                <h4 className="font-bold text-slate-950 text-sm mb-2 uppercase">Violation Telemetry Log:</h4>
                <table className="w-full text-left border-collapse border border-slate-300 text-[11px]">
                  <thead>
                    <tr className="bg-slate-100">
                      <th className="border border-slate-300 p-1.5">Timestamp</th>
                      <th className="border border-slate-300 p-1.5">Event Class</th>
                      <th className="border border-slate-300 p-1.5">Severity</th>
                      <th className="border border-slate-300 p-1.5">Classifier Signature</th>
                    </tr>
                  </thead>
                  <tbody>
                    {violations.map((v, idx) => (
                      <tr key={idx} className={v.severity === 'Critical' ? 'bg-red-50 text-red-900 font-semibold' : ''}>
                        <td className="border border-slate-300 p-1.5">{v.time}</td>
                        <td className="border border-slate-300 p-1.5">{v.type}</td>
                        <td className="border border-slate-300 p-1.5">{v.severity}</td>
                        <td className="border border-slate-300 p-1.5">{v.details}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-900 flex justify-between items-center text-[10px] text-slate-500">
                <span>Cryptographic Digest: SHA256: 8a4f9b2c31e...</span>
                <span>System Verified By: Pavan Gopal Patil (ML Engineering)</span>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left: Real-time Video Stream Viewport */}
            <div className="lg:col-span-7 space-y-4">
              
              <div className="relative aspect-video rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex items-center justify-center">
                {/* Simulated Grid Background */}
                <div className="absolute inset-0 cyber-grid opacity-20 pointer-events-none" />

                {/* Video Stream or Simulated Visualizer */}
                {useWebcam ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform scale-x-[-1]"
                  />
                ) : (
                  <div className="relative w-full h-full flex items-center justify-center bg-gradient-to-br from-[#070d1e] via-[#09142b] to-[#040814]">
                    {!faceAbsent ? (
                      <div className="flex flex-col items-center justify-center">
                        <div className="w-32 h-32 rounded-full border-2 border-dashed border-cyan-400/60 flex items-center justify-center bg-cyan-950/20">
                          <Eye className="w-16 h-16 text-cyan-400 animate-pulse" />
                        </div>
                        <span className="text-xs font-mono text-cyan-300 mt-3 font-semibold">
                          Candidate Face: Tracked (Haar Cascade)
                        </span>
                      </div>
                    ) : (
                      <div className="text-center p-6 bg-red-950/40 rounded-xl border border-red-500/50">
                        <UserMinus className="w-16 h-16 text-red-400 mx-auto animate-bounce" />
                        <span className="text-sm font-mono text-red-400 font-bold block mt-2">
                          WARNING: FACE ABSENT FROM VIEWPORT!
                        </span>
                      </div>
                    )}

                    {/* Simulated 2nd Person */}
                    {multiplePersons && (
                      <div className="absolute top-4 right-6 p-2 rounded-lg bg-amber-950/80 border border-amber-500/60 text-amber-300 text-xs font-mono flex items-center gap-1.5 animate-pulse">
                        <Users className="w-4 h-4 text-amber-400" />
                        <span>Secondary Profile Detected!</span>
                      </div>
                    )}

                    {/* Simulated Phone */}
                    {phoneDetected && (
                      <div className="absolute bottom-6 left-6 p-2 rounded-lg bg-red-950/90 border border-red-500 text-red-300 text-xs font-mono flex items-center gap-1.5 animate-bounce">
                        <Smartphone className="w-4 h-4 text-red-400" />
                        <span>YOLOv3: Cell Phone 95.4%</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Overlaid Computer Vision HUD Elements */}
                <div className="absolute top-3 left-3 flex items-center gap-2 font-mono text-[10px]">
                  <span className="px-2 py-0.5 rounded bg-black/80 text-cyan-400 border border-cyan-500/30 flex items-center gap-1">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                    REC: 30 FPS
                  </span>
                  <span className="px-2 py-0.5 rounded bg-black/80 text-slate-300 border border-slate-700">
                    Resolution: 1280x720
                  </span>
                </div>

                <div className="absolute top-3 right-3 font-mono text-[10px]">
                  <span className={`px-2 py-0.5 rounded border ${
                    phoneDetected || multiplePersons || faceAbsent 
                      ? 'bg-red-950/90 text-red-300 border-red-500 font-bold animate-pulse' 
                      : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                  }`}>
                    {phoneDetected || multiplePersons || faceAbsent ? '⚠️ VIOLATION ACTIVE' : '✓ INTEGRITY NORMAL'}
                  </span>
                </div>

                {/* Scanline */}
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-500/5 to-transparent h-16 w-full animate-scanline pointer-events-none" />
              </div>

              {/* Simulation Testing Control Triggers */}
              <div className="space-y-2">
                <div className="text-xs font-mono text-slate-300 font-semibold flex items-center justify-between">
                  <span>Test Real-Time Computer Vision Violation Triggers:</span>
                  <span className="text-[10px] text-cyan-400">Click to toggle detection states</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    onClick={togglePhone}
                    onMouseEnter={playHover}
                    className={`p-2.5 rounded-xl border text-xs font-mono flex flex-col items-center gap-1 transition-all ${
                      phoneDetected 
                        ? 'bg-red-950 border-red-500 text-red-200 font-bold' 
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <Smartphone className="w-4 h-4 text-red-400" />
                    <span>Phone Detect</span>
                  </button>

                  <button
                    onClick={toggleMultiple}
                    onMouseEnter={playHover}
                    className={`p-2.5 rounded-xl border text-xs font-mono flex flex-col items-center gap-1 transition-all ${
                      multiplePersons 
                        ? 'bg-amber-950 border-amber-500 text-amber-200 font-bold' 
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <Users className="w-4 h-4 text-amber-400" />
                    <span>Multi-Person</span>
                  </button>

                  <button
                    onClick={toggleFaceAbsent}
                    onMouseEnter={playHover}
                    className={`p-2.5 rounded-xl border text-xs font-mono flex flex-col items-center gap-1 transition-all ${
                      faceAbsent 
                        ? 'bg-red-950 border-red-500 text-red-200 font-bold' 
                        : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <UserMinus className="w-4 h-4 text-red-400" />
                    <span>Face Absence</span>
                  </button>

                  <button
                    onClick={simulateTabSwitch}
                    onMouseEnter={playHover}
                    className="p-2.5 rounded-xl border bg-slate-900 border-purple-500/40 hover:border-purple-400 text-purple-300 text-xs font-mono flex flex-col items-center gap-1 transition-all hover:scale-[1.02]"
                  >
                    <AlertTriangle className="w-4 h-4 text-purple-400" />
                    <span>Tab Switch</span>
                  </button>
                </div>
              </div>

            </div>

            {/* Right: Live Violation Log & PDF Report Generator */}
            <div className="lg:col-span-5 bg-gradient-to-b from-[#0a1529] to-[#070e1c] border border-cyan-500/30 rounded-2xl p-5 flex flex-col justify-between space-y-4">
              
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <Activity className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-mono text-slate-300 font-bold">
                      Real-Time Violation Ledger
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">
                    SQLite Sync
                  </span>
                </div>

                {/* Violation list */}
                <div className="h-60 overflow-y-auto space-y-2 pr-1 font-mono text-xs">
                  {violations.map((v) => (
                    <div 
                      key={v.id}
                      className={`p-2.5 rounded-lg border transition-all ${
                        v.severity === 'Critical' 
                          ? 'bg-red-950/40 border-red-500/50 text-red-200' 
                          : v.severity === 'High' 
                          ? 'bg-amber-950/40 border-amber-500/50 text-amber-200' 
                          : 'bg-slate-900/60 border-slate-800 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[10px] text-slate-400">
                        <span className="flex items-center gap-1 font-bold">
                          <Clock className="w-3 h-3 text-cyan-400" />
                          {v.time}
                        </span>
                        <span className={`px-1.5 py-0.2 rounded ${
                          v.severity === 'Critical' ? 'bg-red-900 text-red-200' : 'bg-slate-800 text-slate-300'
                        }`}>
                          {v.severity}
                        </span>
                      </div>
                      <div className="font-semibold mt-1 text-slate-100">{v.type}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{v.details}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action: Generate ReportLab PDF */}
              <div className="pt-3 border-t border-slate-800 space-y-2">
                <button
                  onClick={generateReport}
                  onMouseEnter={playHover}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all hover:scale-[1.01]"
                >
                  <FileDown className="w-4 h-4 text-slate-950" />
                  <span>Generate ReportLab PDF Audit Certificate</span>
                </button>
                <p className="text-[10px] font-mono text-center text-slate-400">
                  Simulates Python ReportLab backend PDF compilation & SQLite session logging
                </p>
              </div>

            </div>

          </div>
        )}

      </div>
    </div>
  );
}
