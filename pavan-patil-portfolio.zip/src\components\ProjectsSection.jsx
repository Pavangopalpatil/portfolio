import React, { useState } from 'react';
import { 
  Sparkles, 
  ExternalLink, 
  Layers, 
  Cpu, 
  CheckCircle2, 
  Bookmark, 
  BookmarkCheck, 
  FileCheck, 
  ChevronRight,
  Database,
  Code2,
  Sliders,
  ShieldCheck,
  Eye,
  Sprout
} from 'lucide-react';
import { PROJECTS } from '../data/portfolioData';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';

export default function ProjectsSection({ onOpenAgroDemo, onOpenProctorDemo }) {
  const { playClick, playHover } = useAudio();
  const { recruiterProfile, toggleBookmarkProject, role } = useUser();
  const [selectedProject, setSelectedProject] = useState(null);

  return (
    <section id="projects" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/50 border border-cyan-500/30 text-xs font-mono text-cyan-400">
            <Sparkles className="w-3.5 h-3.5" />
            <span>FEATURED IMPLEMENTATIONS</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Production-Grade <span className="text-gradient-cyan">Machine Learning Applications</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            End-to-end deployed AI systems solving real challenges in precision agriculture and automated computer vision security.
          </p>
        </div>

        {/* Project Cards Grid */}
        <div className="space-y-12">
          {PROJECTS.map((project, index) => {
            const isBookmarked = recruiterProfile.bookmarkedProjects?.includes(project.id);
            const isAgro = project.id === 'agrosmart';

            return (
              <div
                key={project.id}
                className="group relative rounded-3xl bg-gradient-to-br from-[#091124] via-[#070c1a] to-[#040814] border border-cyan-500/20 hover:border-cyan-500/40 p-6 sm:p-8 lg:p-10 shadow-2xl transition-all duration-300 hover:shadow-cyan-500/10"
              >
                {/* Glow border background effect */}
                <div className={`absolute -inset-0.5 rounded-3xl bg-gradient-to-r ${
                  isAgro ? 'from-emerald-500/20 to-teal-500/10' : 'from-cyan-500/20 to-indigo-500/10'
                } opacity-0 group-hover:opacity-100 transition duration-500 blur-lg pointer-events-none -z-10`} />

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  
                  {/* Left Column: Project Details & Bullets */}
                  <div className="lg:col-span-7 space-y-6">
                    
                    {/* Top tags */}
                    <div className="flex flex-wrap items-center gap-2.5">
                      <span className={`px-3 py-1 rounded-full text-xs font-mono font-bold border ${
                        isAgro 
                          ? 'bg-emerald-950 text-emerald-400 border-emerald-500/40' 
                          : 'bg-cyan-950 text-cyan-400 border-cyan-500/40'
                      }`}>
                        {project.accuracy}
                      </span>
                      <span className="px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-300 text-xs font-mono">
                        {project.category}
                      </span>
                      <span className="px-2.5 py-1 rounded-full bg-slate-900/60 border border-slate-800 text-slate-400 text-xs font-mono">
                        {project.period}
                      </span>

                      {/* Recruiter Shortlist Bookmark Button */}
                      <button
                        onClick={() => {
                          playClick();
                          toggleBookmarkProject(project.id);
                        }}
                        onMouseEnter={playHover}
                        className={`ml-auto flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-mono border transition-all ${
                          isBookmarked 
                            ? 'bg-cyan-950 border-cyan-400 text-cyan-300 font-bold' 
                            : 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-cyan-300'
                        }`}
                        title="Shortlist project for recruiter evaluation"
                      >
                        {isBookmarked ? (
                          <>
                            <BookmarkCheck className="w-3.5 h-3.5 text-cyan-400" />
                            <span>Shortlisted</span>
                          </>
                        ) : (
                          <>
                            <Bookmark className="w-3.5 h-3.5" />
                            <span>{role === 'recruiter' ? 'Shortlist' : 'Bookmark'}</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Title */}
                    <div>
                      <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight group-hover:text-cyan-300 transition-colors">
                        {project.title}
                      </h3>
                      <p className="text-sm font-mono text-cyan-400/90 mt-1">
                        {project.subtitle}
                      </p>
                    </div>

                    {/* Resume Bullets with verified checkmarks */}
                    <div className="space-y-3">
                      {project.bullets.map((bullet, bIdx) => (
                        <div key={bIdx} className="flex items-start gap-3">
                          <CheckCircle2 className={`w-4 h-4 mt-1 shrink-0 ${
                            isAgro ? 'text-emerald-400' : 'text-cyan-400'
                          }`} />
                          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                            {bullet}
                          </p>
                        </div>
                      ))}
                    </div>

                    {/* Tech Stack Badges */}
                    <div className="pt-2">
                      <div className="text-[11px] font-mono text-slate-400 mb-2 uppercase tracking-wider">
                        Engineered With:
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {project.techStack.map((tech) => (
                          <span
                            key={tech}
                            className="px-2.5 py-1 rounded-lg bg-slate-900/90 border border-slate-800 text-[11px] font-mono text-slate-300 hover:border-cyan-500/40 hover:text-cyan-300 transition-colors"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-wrap items-center gap-3 pt-3">
                      <button
                        onClick={() => {
                          playClick();
                          if (isAgro) onOpenAgroDemo();
                          else onOpenProctorDemo();
                        }}
                        onMouseEnter={playHover}
                        className={`px-5 py-3 rounded-xl font-bold text-xs font-mono flex items-center gap-2 shadow-lg transition-all hover:scale-[1.02] ${
                          isAgro 
                            ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-emerald-500/25' 
                            : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 shadow-cyan-500/25'
                        }`}
                      >
                        {isAgro ? <Sprout className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        <span>{isAgro ? "Launch AI Soil Simulator" : "Launch Proctoring Sandbox"}</span>
                      </button>

                      <a
                        href={project.id === 'agrosmart' ? "https://github.com/Pavangopalpatil" : "https://github.com/Pavangopalpatil"}
                        target="_blank"
                        rel="noreferrer"
                        onMouseEnter={playHover}
                        onClick={playClick}
                        className="px-4 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-mono flex items-center gap-1.5 transition-colors"
                      >
                        <Code2 className="w-3.5 h-3.5" />
                        <span>Source Code</span>
                        <ExternalLink className="w-3 h-3 ml-0.5 opacity-60" />
                      </a>
                    </div>

                  </div>

                  {/* Right Column: Architectural Highlights & Performance Metrics Card */}
                  <div className="lg:col-span-5 space-y-4">
                    <div className="rounded-2xl bg-[#060c1c] border border-slate-800 p-6 space-y-5">
                      
                      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                        <span className="text-xs font-mono text-slate-400 uppercase tracking-wider">
                          Key Production Metrics
                        </span>
                        <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                          isAgro ? 'bg-emerald-950 text-emerald-400 border-emerald-500/30' : 'bg-cyan-950 text-cyan-400 border-cyan-500/30'
                        }`}>
                          Verified Benchmark
                        </span>
                      </div>

                      {/* 4 Metric Boxes */}
                      <div className="grid grid-cols-2 gap-3">
                        {project.metrics.map((m, mIdx) => (
                          <div 
                            key={mIdx}
                            className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-850 space-y-1"
                          >
                            <span className="text-[10px] font-mono text-slate-400 block">
                              {m.label}
                            </span>
                            <div className={`text-xl font-bold font-mono ${
                              isAgro ? 'text-emerald-400' : 'text-cyan-400'
                            }`}>
                              {m.value}
                            </div>
                            <span className="text-[10px] text-slate-400 block truncate font-mono">
                              {m.trend}
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* Architectural flow diagram summary */}
                      <div className="pt-2">
                        <span className="text-xs font-mono text-slate-400 block mb-2">
                          End-to-End Pipeline Architecture:
                        </span>
                        <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-slate-300 space-y-1.5">
                          {isAgro ? (
                            <>
                              <div className="flex items-center gap-2">
                                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
                                <span>Input: Soil Image / Texture / NPK & pH Vector</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="h-1.5 w-1.5 rounded-full bg-teal-400"></span>
                                <span>Vision: OpenCV Contour & HSV Color Space</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
                                <span>ML: Scikit-learn Classifier (92-95% acc)</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="h-1.5 w-1.5 rounded-full bg-blue-400"></span>
                                <span>Output: Flask REST API + Cloudflare Delivery</span>
                              </div>
                            </>
                          ) : (
                            <>
                              <div className="flex items-center gap-2">
                                <span className="h-1.5 w-1.5 rounded-full bg-cyan-400"></span>
                                <span>Input: 30 FPS Candidate Webcam Stream</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="h-1.5 w-1.5 rounded-full bg-indigo-400"></span>
                                <span>Vision: Haar Face Absence + Multi-Person Cascade</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="h-1.5 w-1.5 rounded-full bg-purple-400"></span>
                                <span>Edge Detection: YOLOv3-Tiny Mobile Phone Flag</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400"></span>
                                <span>Reporting: ReportLab PDF + SQLite Session Logs</span>
                              </div>
                            </>
                          )}
                        </div>
                      </div>

                    </div>
                  </div>

                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
