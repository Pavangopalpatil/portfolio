import React, { useState } from 'react';
import { 
  Briefcase, 
  X, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle, 
  Send, 
  Bookmark, 
  FileText, 
  Download,
  Building,
  User,
  Search,
  Check,
  TrendingUp
} from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';
import { PERSONAL_INFO, PROJECTS } from '../data/portfolioData';
import confetti from 'canvas-confetti';

export default function RecruiterHubModal({ isOpen, onClose, onOpenResume }) {
  const { playClick, playSuccess, playHover } = useAudio();
  const { 
    recruiterProfile, 
    switchToRecruiter, 
    submitInquiry, 
    trackResumeDownload 
  } = useUser();

  const [activeTab, setActiveTab] = useState('ats'); // 'ats' | 'contact' | 'profile'
  
  // Recruiter form state
  const [recruiterName, setRecruiterName] = useState(recruiterProfile.name || '');
  const [company, setCompany] = useState(recruiterProfile.company || '');
  const [jobTitle, setJobTitle] = useState(recruiterProfile.targetRole || 'ML Engineer');
  const [recruiterEmail, setRecruiterEmail] = useState(recruiterProfile.email || '');

  // ATS state
  const [jobDescription, setJobDescription] = useState(
    "Looking for a Machine Learning and AI Engineer with hands-on experience in Python, Scikit-learn, TensorFlow, and OpenCV. Must have experience building end-to-end ML web applications, computer vision pipelines, and Flask REST API services with SQLite. Experience in deep learning and model deployment is a plus."
  );
  const [atsResult, setAtsResult] = useState(null);
  const [isScanning, setIsScanning] = useState(false);

  // Quick message state
  const [message, setMessage] = useState('');
  const [messageSent, setMessageSent] = useState(false);

  if (!isOpen) return null;

  const handleSaveProfile = (e) => {
    e.preventDefault();
    playClick();
    switchToRecruiter({
      name: recruiterName,
      company: company,
      targetRole: jobTitle,
      email: recruiterEmail
    });
    playSuccess();
  };

  const handleRunATSScan = () => {
    playClick();
    setIsScanning(true);

    setTimeout(() => {
      const lower = jobDescription.toLowerCase();

      const keywords = [
        { term: 'Python', found: lower.includes('python') },
        { term: 'Machine Learning', found: lower.includes('machine learning') || lower.includes('ml') },
        { term: 'Scikit-learn', found: lower.includes('scikit') || lower.includes('sklearn') },
        { term: 'TensorFlow', found: lower.includes('tensorflow') },
        { term: 'PyTorch', found: lower.includes('pytorch') },
        { term: 'OpenCV', found: lower.includes('opencv') || lower.includes('cv') },
        { term: 'Computer Vision', found: lower.includes('computer vision') || lower.includes('vision') },
        { term: 'Flask', found: lower.includes('flask') },
        { term: 'SQLite', found: lower.includes('sqlite') || lower.includes('sql') },
        { term: 'YOLO / Object Detection', found: lower.includes('yolo') || lower.includes('object detection') },
        { term: 'REST API', found: lower.includes('api') || lower.includes('rest') },
        { term: 'Deep Learning', found: lower.includes('deep learning') }
      ];

      const matched = keywords.filter(k => k.found);
      const missing = keywords.filter(k => !k.found);
      
      const score = Math.min(
        99,
        Math.max(68, Math.round((matched.length / Math.max(1, matched.length + missing.length)) * 100) + 12)
      );

      setAtsResult({
        score,
        matched,
        missing,
        verdict: score >= 85 ? "Exceptional Candidate Fit (High Priority)" : "Strong Fit (Meets Primary Requirements)"
      });

      setIsScanning(false);
      playSuccess();
      try {
        confetti({
          particleCount: 50,
          spread: 70,
          origin: { y: 0.6 }
        });
      } catch {}
    }, 600);
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    playClick();

    submitInquiry({
      name: recruiterName || 'Recruiting Partner',
      company: company || 'Enterprise Partner',
      email: recruiterEmail || 'recruiter@company.com',
      role: jobTitle,
      message: message || `Hi Pavan, we analyzed your profile for the ${jobTitle} role and would like to schedule an introductory interview.`,
      priority: 'Urgent'
    });

    setMessageSent(true);
    playSuccess();
    setTimeout(() => setMessageSent(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#091124] border border-cyan-500/40 rounded-2xl shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#060c1c]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <Briefcase className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Recruiter & Hiring Hub
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/30">
                  ATS Suite
                </span>
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Real-time Job Description ATS scoring, fast-track interview pipeline & customized resume
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-6 pt-3 gap-4 text-xs font-mono">
          <button
            onClick={() => setActiveTab('ats')}
            className={`pb-3 font-semibold border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'ats' 
                ? 'border-cyan-400 text-cyan-300' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>ATS Resume Matcher</span>
          </button>

          <button
            onClick={() => setActiveTab('contact')}
            className={`pb-3 font-semibold border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'contact' 
                ? 'border-cyan-400 text-cyan-300' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>Schedule Interview / Fast-Track</span>
          </button>

          <button
            onClick={() => setActiveTab('profile')}
            className={`pb-3 font-semibold border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'profile' 
                ? 'border-cyan-400 text-cyan-300' 
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Building className="w-3.5 h-3.5" />
            <span>Recruiter Preferences</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6">
          
          {/* TAB 1: ATS Resume Matcher */}
          {activeTab === 'ats' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              <div className="lg:col-span-7 space-y-4">
                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1.5 font-semibold">
                    Paste Job Description / Requirement Keywords:
                  </label>
                  <textarea
                    rows={6}
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 p-3 text-xs text-slate-200 font-mono focus:border-cyan-500 focus:outline-none"
                    placeholder="e.g. Seeking Python ML Engineer skilled in Scikit-Learn, OpenCV, Flask, Computer Vision..."
                  />
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-slate-400">
                    Matches against Pavan's verified resume skills & project experience
                  </span>
                  <button
                    onClick={handleRunATSScan}
                    disabled={isScanning}
                    className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs font-mono flex items-center gap-1.5 shadow-lg shadow-cyan-500/25 transition-all"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{isScanning ? "Scanning..." : "Calculate ATS Match %"}</span>
                  </button>
                </div>

                {/* Shortlisted Projects preview */}
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-xs font-mono text-slate-300 font-semibold block mb-2">
                    Recruiter Shortlisted Projects ({recruiterProfile.bookmarkedProjects?.length || 0}):
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {PROJECTS.map(p => {
                      const isShort = recruiterProfile.bookmarkedProjects?.includes(p.id);
                      return (
                        <span 
                          key={p.id}
                          className={`text-[11px] font-mono px-2.5 py-1 rounded-lg border ${
                            isShort ? 'bg-cyan-950 text-cyan-300 border-cyan-500/40' : 'bg-slate-900 text-slate-500 border-slate-800'
                          }`}
                        >
                          {p.title.split('–')[0]} {isShort ? '✓' : ''}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* ATS Results View */}
              <div className="lg:col-span-5 bg-gradient-to-b from-[#0a1529] to-[#070e1c] border border-cyan-500/30 rounded-2xl p-5 flex flex-col justify-between space-y-4">
                {atsResult ? (
                  <div className="space-y-4">
                    <div className="text-center pb-3 border-b border-slate-800">
                      <span className="text-xs font-mono text-slate-400 block">ATS COMPATIBILITY SCORE</span>
                      <div className="text-5xl font-black font-mono text-cyan-400 my-1">
                        {atsResult.score}%
                      </div>
                      <span className="text-xs font-bold text-emerald-400 font-mono">
                        {atsResult.verdict}
                      </span>
                    </div>

                    <div>
                      <span className="text-[11px] font-mono text-slate-300 font-bold block mb-1">
                        Matched Resume Keywords ({atsResult.matched.length}):
                      </span>
                      <div className="flex flex-wrap gap-1">
                        {atsResult.matched.map(k => (
                          <span key={k.term} className="px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono">
                            ✓ {k.term}
                          </span>
                        ))}
                      </div>
                    </div>

                    {atsResult.missing.length > 0 && (
                      <div>
                        <span className="text-[11px] font-mono text-slate-400 block mb-1">
                          Additional Technologies in Profile:
                        </span>
                        <div className="flex flex-wrap gap-1">
                          {atsResult.missing.slice(0, 4).map(k => (
                            <span key={k.term} className="px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800 text-[10px] font-mono">
                              • {k.term}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center p-6 space-y-3">
                    <TrendingUp className="w-12 h-12 text-cyan-400/50 animate-bounce" />
                    <div className="text-sm font-mono text-white font-semibold">
                      Ready for ATS Parsing
                    </div>
                    <p className="text-xs text-slate-400">
                      Click "Calculate ATS Match %" to analyze Pavan's skill alignment with your job description.
                    </p>
                  </div>
                )}

                <div className="pt-2 border-t border-slate-800 flex gap-2">
                  <button
                    onClick={() => {
                      playClick();
                      trackResumeDownload();
                      onOpenResume();
                    }}
                    className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white text-xs font-mono font-bold flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Download Full Resume</span>
                  </button>
                </div>

              </div>

            </div>
          )}

          {/* TAB 2: Fast Track Contact */}
          {activeTab === 'contact' && (
            <form onSubmit={handleSendMessage} className="max-w-xl mx-auto space-y-4">
              <div className="text-center mb-6">
                <h4 className="text-base font-bold text-white">Priority Recruiter Direct Line</h4>
                <p className="text-xs text-slate-400 font-mono mt-1">
                  Messages submitted here bypass spam filters directly to Pavan's priority inbox
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">Your Name</label>
                  <input
                    type="text"
                    required
                    value={recruiterName}
                    onChange={(e) => setRecruiterName(e.target.value)}
                    placeholder="e.g. Sarah Jenkins"
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-mono text-slate-300 block mb-1">Company / Team</label>
                  <input
                    type="text"
                    required
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="e.g. Google / AI Startup"
                    className="w-full rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-mono text-slate-300 block mb-1">Work Email</label>
                <input
                  type="email"
                  required
                  value={recruiterEmail}
                  onChange={(e) => setRecruiterEmail(e.target.value)}
                  placeholder="e.g. sarah@techcorp.com"
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-mono text-slate-300 block mb-1">Invitation / Role Details</label>
                <textarea
                  rows={4}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="We'd love to discuss our upcoming Machine Learning Engineering Internship/Role with you..."
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-xs text-white font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs font-mono flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25"
              >
                {messageSent ? <Check className="w-4 h-4" /> : <Send className="w-4 h-4" />}
                <span>{messageSent ? "Invitation Dispatched Successfully!" : "Dispatch Fast-Track Interview Invitation"}</span>
              </button>
            </form>
          )}

          {/* TAB 3: Preferences / Company Profile */}
          {activeTab === 'profile' && (
            <form onSubmit={handleSaveProfile} className="max-w-md mx-auto space-y-4">
              <div className="text-center mb-4">
                <h4 className="text-base font-bold text-white">Save Recruiter Session Profile</h4>
                <p className="text-xs text-slate-400 font-mono mt-1">
                  Enables tailored ATS match suggestions and bookmarking across your session
                </p>
              </div>

              <div>
                <label className="text-xs font-mono text-slate-300 block mb-1">Recruiter Name</label>
                <input
                  type="text"
                  value={recruiterName}
                  onChange={(e) => setRecruiterName(e.target.value)}
                  placeholder="Your Name"
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-mono text-slate-300 block mb-1">Organization / Agency</label>
                <input
                  type="text"
                  value={company}
                  onChange={(e) => setCompany(e.target.value)}
                  placeholder="Company Name"
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="text-xs font-mono text-slate-300 block mb-1">Target Role to Fill</label>
                <input
                  type="text"
                  value={jobTitle}
                  onChange={(e) => setJobTitle(e.target.value)}
                  placeholder="e.g. AI Engineer, Computer Vision Intern"
                  className="w-full rounded-xl bg-slate-950 border border-slate-800 p-2.5 text-xs text-white font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold text-xs font-mono"
              >
                Save & Activate Recruiter View
              </button>
            </form>
          )}

        </div>

      </div>
    </div>
  );
}
