import React, { useState } from 'react';
import { 
  X, 
  Printer, 
  Copy, 
  Check, 
  Download, 
  ExternalLink, 
  Sparkles, 
  FileText 
} from 'lucide-react';
import { PERSONAL_INFO, EDUCATION, PROJECTS, CERTIFICATIONS, SKILLS } from '../data/portfolioData';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';
import confetti from 'canvas-confetti';

export default function ResumeViewerModal({ isOpen, onClose }) {
  const { playClick, playSuccess } = useAudio();
  const { trackResumeDownload } = useUser();
  const [copied, setCopied] = useState(false);
  const [highlightAts, setHighlightAts] = useState(false);

  if (!isOpen) return null;

  const handlePrint = () => {
    playClick();
    trackResumeDownload();
    window.print();
  };

  const handleCopyText = () => {
    playClick();
    trackResumeDownload();

    const plainText = `
PAVAN GOPAL PATIL
${PERSONAL_INFO.email} | ${PERSONAL_INFO.phone}
LinkedIn: ${PERSONAL_INFO.linkedin}
GitHub: ${PERSONAL_INFO.github}

SUMMARY
${PERSONAL_INFO.summary}

EDUCATION
${EDUCATION.institution} (Expected ${EDUCATION.period})
${EDUCATION.degree} | CGPA: ${EDUCATION.cgpa}

TECHNICAL SKILLS
• Programming Languages: Python, SQL
• Machine Learning Libraries: Scikit-learn, TensorFlow, PyTorch, NumPy, Pandas
• Core Competencies: Machine Learning, Deep Learning, Natural Language Processing (NLP), Computer Vision
• Tools & Platforms: Jupyter Notebook, Git, GitHub, VS Code, Flask, SQLite

PROJECTS
1. AgroSmart – AI-Powered Smart Agriculture Portal
- Designed and developed a full-stack, AI-powered agriculture web platform that analyzes soil composition and delivers real-time crop, fertilizer, and weather-based farming recommendations to end users.
- Built and trained machine learning models using Scikit-learn and OpenCV for soil image classification, achieving 92–95% classification accuracy.
- Engineered a Flask REST API backend integrated with an SQLite database to serve ML predictions and manage user and farm data.
- Implemented a responsive frontend using HTML5, CSS3, and JavaScript, and deployed the application using Cloudflare (frontend) and a Flask server (backend).
Tech Stack: Python, Flask, Scikit-learn, OpenCV, NumPy, Pandas, SQLite, HTML5, CSS3, JavaScript, Git

2. AI-Based Online Exam Proctoring System
- Developed a real-time AI proctoring system that monitors students via webcam and automatically flags suspicious activity during online examinations, ensuring exam integrity.
- Implemented face absence, multiple-person, and mobile phone detection using OpenCV, YOLOv3-Tiny, and Haar Cascade classifiers, achieving 95% detection accuracy.
- Built automated violation logging and tab-switch detection using browser APIs, and generated downloadable integrity reports using ReportLab.
- Designed the backend with Python and Flask, using SQLite for persistent storage of session and violation data.
Tech Stack: Python, Flask, OpenCV, YOLOv3-Tiny, Haar Cascade, NumPy, ReportLab, SQLite, HTML, CSS, JavaScript, Bootstrap

CERTIFICATIONS
- Data Structures and Algorithms – CodeChef
- Python Programming – CodeChef
- Database Management System – CodeChef
- Machine Learning – NPTEL
- Business Statistics – NPTEL
    `.trim();

    navigator.clipboard.writeText(plainText);
    setCopied(true);
    playSuccess();
    try {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch {}
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-[#091124] border border-cyan-500/40 rounded-2xl shadow-2xl overflow-hidden my-4 flex flex-col max-h-[92vh]">
        
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-6 py-3.5 border-b border-slate-800 bg-[#060c1c]">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-500/40 text-cyan-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                Official Resume Document
              </h3>
              <p className="text-xs text-slate-400 font-mono">
                Pavan Gopal Patil • Verified Machine Learning & AI Engineer
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setHighlightAts(!highlightAts)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono transition-all ${
                highlightAts 
                  ? 'bg-cyan-950 text-cyan-300 border-cyan-400 font-bold' 
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 inline mr-1" />
              {highlightAts ? "ATS Highlights Active" : "Highlight ATS Keywords"}
            </button>

            <button
              onClick={handleCopyText}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-mono flex items-center gap-1.5"
              title="Copy plain text version"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Copied!" : "Copy Text"}</span>
            </button>

            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs font-mono flex items-center gap-1.5 shadow-md shadow-cyan-500/25"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg bg-slate-900/80 hover:bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Paper Container */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-950">
          <div className="bg-white text-slate-900 p-8 sm:p-12 rounded-xl shadow-2xl max-w-3xl mx-auto font-sans text-xs leading-normal select-text">
            
            {/* Header */}
            <div className="text-center border-b-2 border-slate-900 pb-4 mb-4">
              <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-950 uppercase">
                {PERSONAL_INFO.name}
              </h1>
              <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1 mt-2 text-slate-700 font-mono text-[11px]">
                <a href={`mailto:${PERSONAL_INFO.email}`} className="hover:underline text-blue-800 font-medium">{PERSONAL_INFO.email}</a>
                <span>|</span>
                <span className="font-medium">{PERSONAL_INFO.phone}</span>
                <span>|</span>
                <a href={PERSONAL_INFO.linkedin} target="_blank" rel="noreferrer" className="hover:underline text-blue-800">
                  linkedin.com/in/{PERSONAL_INFO.linkedinUsername}
                </a>
                <span>|</span>
                <a href={PERSONAL_INFO.github} target="_blank" rel="noreferrer" className="hover:underline text-blue-800">
                  github.com/{PERSONAL_INFO.githubUsername}
                </a>
              </div>
            </div>

            {/* Summary */}
            <div className="mb-4">
              <h2 className="text-sm font-bold tracking-wider uppercase text-slate-950 border-b border-slate-300 pb-1 mb-2 font-mono">
                Summary
              </h2>
              <p className="text-slate-800 text-[11px] leading-relaxed">
                {highlightAts ? (
                  <>
                    <mark className="bg-yellow-200">Machine Learning and AI Engineer</mark> with hands-on experience building end-to-end ML-powered web applications, including <mark className="bg-yellow-200">computer vision</mark> and predictive systems. Skilled in <mark className="bg-cyan-200">Python</mark>, <mark className="bg-cyan-200">Scikit-learn</mark>, <mark className="bg-cyan-200">TensorFlow</mark>, and <mark className="bg-cyan-200">OpenCV</mark>, with a track record of delivering functional, deployed projects achieving <mark className="bg-green-200">92–95% accuracy</mark>.
                  </>
                ) : (
                  PERSONAL_INFO.summary
                )}
              </p>
            </div>

            {/* Education */}
            <div className="mb-4">
              <h2 className="text-sm font-bold tracking-wider uppercase text-slate-950 border-b border-slate-300 pb-1 mb-2 font-mono">
                Education
              </h2>
              <div className="flex justify-between items-start text-[11px]">
                <div>
                  <h3 className="font-bold text-slate-900">{EDUCATION.institution}</h3>
                  <p className="text-slate-700">{EDUCATION.degree}</p>
                </div>
                <div className="text-right font-mono text-[11px]">
                  <p className="font-bold text-slate-900">{EDUCATION.period}</p>
                  <p className="text-slate-700">CGPA: {EDUCATION.cgpa}</p>
                </div>
              </div>
            </div>

            {/* Technical Skills */}
            <div className="mb-4">
              <h2 className="text-sm font-bold tracking-wider uppercase text-slate-950 border-b border-slate-300 pb-1 mb-2 font-mono">
                Technical Skills
              </h2>
              <ul className="space-y-1 text-[11px] text-slate-800">
                <li>
                  <span className="font-bold">Programming Languages:</span> Python, SQL
                </li>
                <li>
                  <span className="font-bold">Machine Learning Libraries:</span> Scikit-learn, TensorFlow, PyTorch, NumPy, Pandas
                </li>
                <li>
                  <span className="font-bold">Core Competencies:</span> Machine Learning, Deep Learning, Natural Language Processing (NLP), Computer Vision
                </li>
                <li>
                  <span className="font-bold">Tools & Platforms:</span> Jupyter Notebook, Git, GitHub, VS Code, Flask, SQLite
                </li>
              </ul>
            </div>

            {/* Projects */}
            <div className="mb-4">
              <h2 className="text-sm font-bold tracking-wider uppercase text-slate-950 border-b border-slate-300 pb-1 mb-2 font-mono">
                Projects
              </h2>
              
              {/* Project 1 */}
              <div className="mb-3">
                <div className="flex justify-between items-baseline">
                  <h3 className="font-bold text-slate-950 text-xs">
                    AgroSmart – AI-Powered Smart Agriculture Portal
                  </h3>
                </div>
                <ul className="list-disc pl-4 mt-1 space-y-1 text-[11px] text-slate-800">
                  <li>Designed and developed a full-stack, AI-powered agriculture web platform that analyzes soil composition and delivers real-time crop, fertilizer, and weather-based farming recommendations to end users.</li>
                  <li>Built and trained machine learning models using Scikit-learn and OpenCV for soil image classification, achieving 92–95% classification accuracy.</li>
                  <li>Engineered a Flask REST API backend integrated with an SQLite database to serve ML predictions and manage user and farm data.</li>
                  <li>Implemented a responsive frontend using HTML5, CSS3, and JavaScript, and deployed the application using Cloudflare (frontend) and a Flask server (backend).</li>
                </ul>
                <p className="mt-1 text-[10px] font-mono text-slate-600 pl-4">
                  <span className="font-bold">Tech Stack:</span> Python, Flask, Scikit-learn, OpenCV, NumPy, Pandas, SQLite, HTML5, CSS3, JavaScript, Git
                </p>
              </div>

              {/* Project 2 */}
              <div>
                <div className="flex justify-between items-baseline">
                  <h3 className="font-bold text-slate-950 text-xs">
                    AI-Based Online Exam Proctoring System
                  </h3>
                </div>
                <ul className="list-disc pl-4 mt-1 space-y-1 text-[11px] text-slate-800">
                  <li>Developed a real-time AI proctoring system that monitors students via webcam and automatically flags suspicious activity during online examinations, ensuring exam integrity.</li>
                  <li>Implemented face absence, multiple-person, and mobile phone detection using OpenCV, YOLOv3-Tiny, and Haar Cascade classifiers, achieving 95% detection accuracy.</li>
                  <li>Built automated violation logging and tab-switch detection using browser APIs, and generated downloadable integrity reports using ReportLab.</li>
                  <li>Designed the backend with Python and Flask, using SQLite for persistent storage of session and violation data.</li>
                </ul>
                <p className="mt-1 text-[10px] font-mono text-slate-600 pl-4">
                  <span className="font-bold">Tech Stack:</span> Python, Flask, OpenCV, YOLOv3-Tiny, Haar Cascade, NumPy, ReportLab, SQLite, HTML, CSS, JavaScript, Bootstrap
                </p>
              </div>
            </div>

            {/* Certifications */}
            <div>
              <h2 className="text-sm font-bold tracking-wider uppercase text-slate-950 border-b border-slate-300 pb-1 mb-2 font-mono">
                Certifications
              </h2>
              <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-slate-800">
                <li>Data Structures and Algorithms – CodeChef</li>
                <li>Python Programming – CodeChef</li>
                <li>Database Management System – CodeChef</li>
                <li>Machine Learning – NPTEL</li>
                <li>Business Statistics – NPTEL</li>
              </ul>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
}
