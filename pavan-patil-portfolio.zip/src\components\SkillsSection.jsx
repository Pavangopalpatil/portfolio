import React, { useState } from 'react';
import { 
  Code2, 
  Brain, 
  Eye, 
  Server, 
  Sparkles, 
  Check, 
  Cpu, 
  Terminal,
  Zap,
  Filter
} from 'lucide-react';
import { SKILLS } from '../data/portfolioData';
import { useAudio } from '../context/AudioContext';

export default function SkillsSection() {
  const { playClick, playHover } = useAudio();
  const [activeCategory, setActiveCategory] = useState("All");

  const categories = ["All", ...SKILLS.map(s => s.category)];

  const iconMap = {
    Code2: Code2,
    Brain: Brain,
    Eye: Eye,
    Server: Server
  };

  const filteredCategories = activeCategory === "All" 
    ? SKILLS 
    : SKILLS.filter(s => s.category === activeCategory);

  return (
    <section id="skills" className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/50 border border-cyan-500/30 text-xs font-mono text-cyan-400">
            <Cpu className="w-3.5 h-3.5" />
            <span>TECHNICAL PROFICIENCY</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Skill Matrix & <span className="text-gradient-cyan">AI Core Competencies</span>
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            Proficiency verified across production implementations, computer vision pipelines, and scalable database schemas.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => {
                playClick();
                setActiveCategory(cat);
              }}
              onMouseEnter={playHover}
              className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
                activeCategory === cat
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold shadow-lg shadow-cyan-500/25 scale-105'
                  : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Skills Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredCategories.map((group, groupIdx) => {
            const Icon = iconMap[group.icon] || Code2;
            return (
              <div
                key={groupIdx}
                className="rounded-2xl bg-gradient-to-br from-[#091124] to-[#070c1a] border border-cyan-500/20 p-6 shadow-xl space-y-5"
              >
                {/* Category Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-cyan-950 border border-cyan-500/30 text-cyan-400">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white">{group.category}</h3>
                      <p className="text-[11px] font-mono text-slate-400">
                        {group.skills.length} Technical Proficiencies
                      </p>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-900 text-cyan-300 border border-slate-700">
                    Production Stack
                  </span>
                </div>

                {/* Individual Skill Items */}
                <div className="space-y-4">
                  {group.skills.map((skill, sIdx) => (
                    <div 
                      key={sIdx}
                      className="group/item p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:border-cyan-500/40 transition-all"
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold text-white group-hover/item:text-cyan-300 transition-colors">
                            {skill.name}
                          </span>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-400 border border-cyan-500/30">
                            {skill.badge}
                          </span>
                        </div>
                        <span className="text-xs font-mono font-bold text-cyan-400">
                          {skill.level}%
                        </span>
                      </div>

                      {/* Animated Progress Bar */}
                      <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden p-[1px] border border-slate-800">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 transition-all duration-1000 shadow-sm shadow-cyan-400"
                          style={{ width: `${skill.level}%` }}
                        />
                      </div>

                      {/* Brief description */}
                      <p className="text-[11px] text-slate-400 mt-2 font-mono">
                        {skill.description}
                      </p>
                    </div>
                  ))}
                </div>

              </div>
            );
          })}
        </div>

        {/* Skill Highlights Callout Bar */}
        <div className="mt-12 p-6 rounded-2xl bg-slate-900/60 border border-slate-800 backdrop-blur-md grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-xl font-bold font-mono text-cyan-400">Real-Time OpenCV</div>
            <p className="text-xs text-slate-400 mt-1">Multi-modal webcam vision with YOLOv3-Tiny and Haar Cascades</p>
          </div>
          <div className="border-y md:border-y-0 md:border-x border-slate-800 py-4 md:py-0">
            <div className="text-xl font-bold font-mono text-emerald-400">92-95% Accuracy</div>
            <p className="text-xs text-slate-400 mt-1">Scikit-learn classification on multi-class soil dataset</p>
          </div>
          <div>
            <div className="text-xl font-bold font-mono text-purple-400">Flask REST & SQLite</div>
            <p className="text-xs text-slate-400 mt-1">Microservices architecture with Cloudflare edge distribution</p>
          </div>
        </div>

      </div>
    </section>
  );
}
