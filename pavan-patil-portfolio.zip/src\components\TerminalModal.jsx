import React, { useState, useEffect, useRef } from 'react';
import { Terminal, X, Minimize2, Maximize2, Sparkles, CornerDownLeft } from 'lucide-react';
import { useAudio } from '../context/AudioContext';
import { useUser } from '../context/UserContext';
import { PERSONAL_INFO, EDUCATION, PROJECTS, SKILLS } from '../data/portfolioData';

export default function TerminalModal({ isOpen, onClose, onOpenRecruiterHub, onOpenAdminModal }) {
  const { playClick, playTerminalKey, playAlert, playSuccess } = useAudio();
  const { loginAdmin } = useUser();

  const [inputVal, setInputVal] = useState('');
  const [history, setHistory] = useState([
    { type: 'system', text: 'PavanOS v2.4 (x86_64-ml-core) initialized.' },
    { type: 'system', text: 'Type "help" for a list of available AI/ML shell commands.' }
  ]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [commandHistory, setCommandHistory] = useState([]);

  const inputRef = useRef(null);
  const terminalEndRef = useRef(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  if (!isOpen) return null;

  const handleCommand = (cmdStr) => {
    const trimmed = cmdStr.trim();
    if (!trimmed) return;

    setCommandHistory(prev => [...prev, trimmed]);
    setHistoryIndex(-1);

    const args = trimmed.split(' ');
    const command = args[0].toLowerCase();

    const newHistory = [...history, { type: 'user', text: `$ ${trimmed}` }];

    switch (command) {
      case 'help':
        newHistory.push({
          type: 'output',
          text: `Available commands:
  • help                 - Show this help menu
  • about                - Display engineer bio and academic track
  • skills               - List machine learning & software proficiencies
  • projects             - Show AgroSmart & AI Proctoring project summaries
  • predict --soil <val> - Run quick ML crop prediction (e.g. predict --soil black)
  • proctor --status     - Check simulated CV proctoring state
  • cat resume           - Display full ASCII resume
  • contact              - Display phone, email, and social profiles
  • hire                 - Open Recruiter Hub & ATS Matcher
  • sudo admin           - Log in as Pavan (Owner Mode, default PIN: 2028)
  • clear                - Clear the terminal screen`
        });
        playClick();
        break;

      case 'about':
        newHistory.push({
          type: 'output',
          text: `Name: ${PERSONAL_INFO.name}
Role: ${PERSONAL_INFO.role}
Education: ${EDUCATION.institution} (${EDUCATION.period})
Degree: ${EDUCATION.degree} | CGPA: ${EDUCATION.cgpa}
Summary: ${PERSONAL_INFO.summary}`
        });
        playClick();
        break;

      case 'skills':
        newHistory.push({
          type: 'output',
          text: `TECHNICAL SKILL MATRIX:
• Programming: Python (95%), SQL (85%), JavaScript (80%)
• ML & DL: Scikit-learn, TensorFlow, PyTorch, NumPy, Pandas
• Computer Vision & NLP: OpenCV, YOLOv3-Tiny, Haar Cascades, NLP
• Backend & Tools: Flask, SQLite, Cloudflare, ReportLab, Git, VS Code`
        });
        playClick();
        break;

      case 'projects':
        newHistory.push({
          type: 'output',
          text: `PRODUCTION PROJECTS:
[1] AgroSmart – AI-Powered Smart Agriculture Portal
    • 92-95% classification accuracy via Scikit-learn + OpenCV
    • Flask REST API + SQLite + Cloudflare deployment

[2] AI-Based Online Exam Proctoring System
    • 95% detection accuracy via YOLOv3-Tiny & Haar Cascades
    • Real-time webcam face absence, mobile phone & multi-person flags
    • Automated ReportLab PDF audit logs`
        });
        playClick();
        break;

      case 'predict':
        const soilArg = args[2] || 'black';
        newHistory.push({
          type: 'output',
          text: `[ML INFERENCE] Evaluating Soil Sample '${soilArg}'...
» Classifier: Scikit-Learn RandomForestClassifier
» Predicted Crop: Cotton (Bt Hybrid) / Wheat
» Model Confidence: 94.6%
» Fertilizer Prescription: Urea (46% N) + SSP`
        });
        playSuccess();
        break;

      case 'proctor':
        newHistory.push({
          type: 'output',
          text: `[COMPUTER VISION TELEMETRY]
» Stream: 30.2 FPS @ 1280x720
» Face Cascade: Active (1 Face Present)
» YOLOv3-Tiny: Mobile Device [Negative]
» Tab Activity: Focused (Window Active)
» Integrity Score: 98.5% [SAFE]`
        });
        playSuccess();
        break;

      case 'cat':
        if (args[1] === 'resume' || args[1] === 'resume.txt') {
          newHistory.push({
            type: 'output',
            text: `------------------------------------------------------------
PAVAN GOPAL PATIL - MACHINE LEARNING & AI ENGINEER
Email: ${PERSONAL_INFO.email} | Phone: ${PERSONAL_INFO.phone}
LinkedIn: ${PERSONAL_INFO.linkedin}
GitHub: ${PERSONAL_INFO.github}
------------------------------------------------------------
EDUCATION:
R. C. Patel Institute of Technology, Shirpur (Expected 2028)
B.Tech CSE (Data Science) | CGPA: 7.0/10

PROJECTS:
1. AgroSmart (92-95% accuracy) - Python, Flask, Scikit-learn, OpenCV
2. AI Proctoring (95% accuracy) - Python, Flask, OpenCV, YOLOv3-Tiny

CERTIFICATIONS:
CodeChef: DSA, Python, DBMS | NPTEL: Machine Learning, Business Statistics`
          });
          playSuccess();
        } else {
          newHistory.push({
            type: 'output',
            text: `cat: file not found. Try 'cat resume'`
          });
        }
        break;

      case 'contact':
        newHistory.push({
          type: 'output',
          text: `Direct Contact Channels:
• Email: ${PERSONAL_INFO.email}
• Phone: ${PERSONAL_INFO.phone}
• LinkedIn: ${PERSONAL_INFO.linkedin}
• GitHub: ${PERSONAL_INFO.github}`
        });
        playClick();
        break;

      case 'hire':
        newHistory.push({
          type: 'output',
          text: `Opening Recruiter Hub...`
        });
        playSuccess();
        setTimeout(() => {
          onClose();
          onOpenRecruiterHub();
        }, 500);
        break;

      case 'sudo':
        if (args[1] === 'admin') {
          const pin = prompt("Enter Admin PIN (Default: 2028):");
          if (loginAdmin(pin)) {
            newHistory.push({
              type: 'output',
              text: `[AUTH SUCCESS] Elevated permissions granted. Welcome, Pavan!`
            });
            setTimeout(() => {
              onClose();
              onOpenAdminModal();
            }, 600);
          } else {
            newHistory.push({
              type: 'output',
              text: `[AUTH FAILED] Permission denied.`
            });
          }
        } else {
          newHistory.push({
            type: 'output',
            text: `Unknown sudo target. Try 'sudo admin'.`
          });
        }
        break;

      case 'clear':
        setHistory([]);
        setInputVal('');
        return;

      default:
        newHistory.push({
          type: 'output',
          text: `Command not found: "${trimmed}". Type "help" for a list of commands.`
        });
        playAlert();
        break;
    }

    setHistory(newHistory);
    setInputVal('');
  };

  const handleKeyDown = (e) => {
    playTerminalKey();
    if (e.key === 'Enter') {
      handleCommand(inputVal);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const nextIdx = historyIndex + 1;
        if (nextIdx < commandHistory.length) {
          setHistoryIndex(nextIdx);
          setInputVal(commandHistory[commandHistory.length - 1 - nextIdx]);
        }
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const nextIdx = historyIndex - 1;
        setHistoryIndex(nextIdx);
        setInputVal(commandHistory[commandHistory.length - 1 - nextIdx]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setInputVal('');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-3xl bg-[#050914] border border-cyan-500/40 rounded-2xl shadow-2xl overflow-hidden font-mono text-xs flex flex-col h-[520px] animate-in fade-in zoom-in-95 duration-150">
        
        {/* Terminal Header Bar */}
        <div className="flex items-center justify-between px-4 py-3 bg-[#0a1124] border-b border-cyan-500/20 select-none">
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-red-500/80 cursor-pointer" onClick={onClose} />
            <div className="h-3 w-3 rounded-full bg-amber-500/80" />
            <div className="h-3 w-3 rounded-full bg-emerald-500/80" />
            <span className="text-slate-400 font-bold ml-2 flex items-center gap-1.5 text-[11px]">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              pavan@ml-station:~ (bash)
            </span>
          </div>
          <div className="flex items-center gap-2 text-slate-400">
            <span className="text-[10px] text-cyan-400 px-2 py-0.5 rounded bg-cyan-950/60 border border-cyan-500/30">
              Interactive CLI
            </span>
            <button onClick={onClose} className="hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Terminal Content Screen */}
        <div className="flex-1 p-4 overflow-y-auto space-y-2 text-slate-300">
          {history.map((line, i) => (
            <div key={i} className="leading-relaxed">
              {line.type === 'system' && (
                <div className="text-cyan-400/80">{line.text}</div>
              )}
              {line.type === 'user' && (
                <div className="text-emerald-400 font-semibold">{line.text}</div>
              )}
              {line.type === 'output' && (
                <pre className="text-slate-300 whitespace-pre-wrap font-mono mt-0.5">{line.text}</pre>
              )}
            </div>
          ))}
          <div ref={terminalEndRef} />
        </div>

        {/* Terminal Input Bar */}
        <div className="px-4 py-3 bg-[#080e1e] border-t border-slate-800 flex items-center gap-2">
          <span className="text-emerald-400 font-bold">pavan@ml:~$</span>
          <input
            ref={inputRef}
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent text-white outline-none font-mono text-xs caret-cyan-400"
            placeholder="Type 'help', 'predict --soil black', 'cat resume'..."
            autoFocus
          />
          <button
            onClick={() => handleCommand(inputVal)}
            className="p-1.5 rounded-lg bg-cyan-950 text-cyan-400 hover:bg-cyan-900 border border-cyan-500/30"
          >
            <CornerDownLeft className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>
    </div>
  );
}
