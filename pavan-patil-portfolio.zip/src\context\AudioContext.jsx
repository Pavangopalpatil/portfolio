import React, { createContext, useContext, useState, useEffect, useRef } from 'react';

const AudioContext = createContext(null);

export function AudioProvider({ children }) {
  const [soundEnabled, setSoundEnabled] = useState(() => {
    return localStorage.getItem('pavan_portfolio_sound') === 'true';
  });
  const audioCtxRef = useRef(null);

  useEffect(() => {
    localStorage.setItem('pavan_portfolio_sound', soundEnabled);
  }, [soundEnabled]);

  const initAudio = () => {
    if (!audioCtxRef.current && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        audioCtxRef.current = new AudioCtx();
      }
    }
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  };

  const playBeep = (freq = 440, duration = 0.08, type = 'sine', gainVal = 0.05) => {
    if (!soundEnabled) return;
    try {
      initAudio();
      const ctx = audioCtxRef.current;
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime);

      gainNode.gain.setValueAtTime(gainVal, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);

      osc.connect(gainNode);
      gainNode.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Audio autoplay policy fallback
    }
  };

  const playClick = () => playBeep(620, 0.05, 'triangle', 0.04);
  const playHover = () => playBeep(380, 0.03, 'sine', 0.015);
  const playSuccess = () => {
    if (!soundEnabled) return;
    playBeep(523.25, 0.1, 'sine', 0.04);
    setTimeout(() => playBeep(659.25, 0.12, 'sine', 0.05), 90);
    setTimeout(() => playBeep(783.99, 0.18, 'sine', 0.06), 180);
  };
  const playAlert = () => {
    if (!soundEnabled) return;
    playBeep(320, 0.12, 'sawtooth', 0.05);
    setTimeout(() => playBeep(240, 0.15, 'sawtooth', 0.06), 110);
  };
  const playTerminalKey = () => playBeep(700 + Math.random() * 200, 0.03, 'square', 0.015);

  const toggleSound = () => {
    setSoundEnabled(prev => {
      const next = !prev;
      if (next) {
        setTimeout(() => playSuccess(), 50);
      }
      return next;
    });
  };

  return (
    <AudioContext.Provider
      value={{
        soundEnabled,
        toggleSound,
        playClick,
        playHover,
        playSuccess,
        playAlert,
        playTerminalKey
      }}
    >
      {children}
    </AudioContext.Provider>
  );
}

export function useAudio() {
  const context = useContext(AudioContext);
  if (!context) {
    return {
      soundEnabled: false,
      toggleSound: () => {},
      playClick: () => {},
      playHover: () => {},
      playSuccess: () => {},
      playAlert: () => {},
      playTerminalKey: () => {}
    };
  }
  return context;
}
