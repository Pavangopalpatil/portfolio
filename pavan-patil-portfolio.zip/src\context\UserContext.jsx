import React, { createContext, useContext, useState, useEffect } from 'react';
import { INITIAL_GUESTBOOK, INITIAL_INQUIRIES, INITIAL_ANALYTICS } from '../data/portfolioData';

const UserContext = createContext(null);

export function UserProvider({ children }) {
  // Current user role: 'guest' | 'recruiter' | 'admin'
  const [role, setRole] = useState(() => {
    return localStorage.getItem('pavan_portfolio_role') || 'guest';
  });

  // Recruiter Profile
  const [recruiterProfile, setRecruiterProfile] = useState(() => {
    const saved = localStorage.getItem('pavan_recruiter_profile');
    return saved ? JSON.parse(saved) : {
      name: '',
      company: '',
      targetRole: 'Machine Learning Engineer',
      email: '',
      notes: '',
      bookmarkedProjects: ['agrosmart', 'proctoring']
    };
  });

  // Admin Authentication
  const [isAdminAuth, setIsAdminAuth] = useState(() => {
    return localStorage.getItem('pavan_admin_auth') === 'true';
  });

  // Live Announcement (editable by admin)
  const [announcement, setAnnouncement] = useState(() => {
    return localStorage.getItem('pavan_announcement') || 
      "🚀 Open for Summer 2026/2027 Machine Learning & AI Engineering Internships! Open to Relocation & Remote.";
  });

  // Guestbook comments
  const [guestbook, setGuestbook] = useState(() => {
    const saved = localStorage.getItem('pavan_guestbook');
    return saved ? JSON.parse(saved) : INITIAL_GUESTBOOK;
  });

  // Inquiries / Recruiter Leads
  const [inquiries, setInquiries] = useState(() => {
    const saved = localStorage.getItem('pavan_inquiries');
    return saved ? JSON.parse(saved) : INITIAL_INQUIRIES;
  });

  // Analytics
  const [analytics, setAnalytics] = useState(() => {
    const saved = localStorage.getItem('pavan_analytics');
    return saved ? JSON.parse(saved) : INITIAL_ANALYTICS;
  });

  // Toast notifications
  const [toast, setToast] = useState(null);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('pavan_portfolio_role', role);
  }, [role]);

  useEffect(() => {
    localStorage.setItem('pavan_recruiter_profile', JSON.stringify(recruiterProfile));
  }, [recruiterProfile]);

  useEffect(() => {
    localStorage.setItem('pavan_admin_auth', isAdminAuth);
  }, [isAdminAuth]);

  useEffect(() => {
    localStorage.setItem('pavan_announcement', announcement);
  }, [announcement]);

  useEffect(() => {
    localStorage.setItem('pavan_guestbook', JSON.stringify(guestbook));
  }, [guestbook]);

  useEffect(() => {
    localStorage.setItem('pavan_inquiries', JSON.stringify(inquiries));
  }, [inquiries]);

  useEffect(() => {
    localStorage.setItem('pavan_analytics', JSON.stringify(analytics));
  }, [analytics]);

  const showToast = (message, type = 'success') => {
    setToast({ id: Date.now(), message, type });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // Role switching
  const switchToGuest = () => {
    setRole('guest');
    showToast("Switched to Visitor / Guest Mode", "info");
  };

  const switchToRecruiter = (profileData = {}) => {
    setRole('recruiter');
    if (Object.keys(profileData).length > 0) {
      setRecruiterProfile(prev => ({ ...prev, ...profileData }));
    }
    showToast("Welcome to Recruiter Hub Mode! Customized ATS tools unlocked.", "success");
  };

  const loginAdmin = (enteredPin) => {
    // Default PIN: 2028 (graduation year) or 'pavan123'
    if (enteredPin === '2028' || enteredPin === 'pavan123') {
      setIsAdminAuth(true);
      setRole('admin');
      showToast("Access Granted. Welcome, Pavan Gopal Patil! Admin Control Panel active.", "success");
      return true;
    } else {
      showToast("Invalid Admin PIN. (Default test PIN is 2028)", "error");
      return false;
    }
  };

  const logoutAdmin = () => {
    setIsAdminAuth(false);
    setRole('guest');
    showToast("Admin logged out.", "info");
  };

  // Recruiter project bookmark toggle
  const toggleBookmarkProject = (projectId) => {
    setRecruiterProfile(prev => {
      const exists = prev.bookmarkedProjects.includes(projectId);
      const updated = exists
        ? prev.bookmarkedProjects.filter(id => id !== projectId)
        : [...prev.bookmarkedProjects, projectId];
      showToast(exists ? "Removed from recruiter shortlist" : "Shortlisted project for committee review!", "success");
      return { ...prev, bookmarkedProjects: updated };
    });
  };

  // Add inquiry from contact form or recruiter modal
  const submitInquiry = (inquiryData) => {
    const newEntry = {
      id: `inq-${Date.now()}`,
      name: inquiryData.name || 'Anonymous Recruiter',
      company: inquiryData.company || 'Confidential',
      email: inquiryData.email,
      role: inquiryData.role || 'Hiring Team',
      message: inquiryData.message,
      date: 'Just now',
      status: 'New',
      priority: inquiryData.priority || 'High'
    };

    setInquiries(prev => [newEntry, ...prev]);
    setAnalytics(prev => ({ ...prev, recruiterInquiries: prev.recruiterInquiries + 1 }));
    showToast("Message delivered directly to Pavan's priority inbox!", "success");
  };

  // Admin update inquiry status
  const updateInquiryStatus = (id, newStatus) => {
    setInquiries(prev => prev.map(item => item.id === id ? { ...item, status: newStatus } : item));
    showToast(`Status updated to: ${newStatus}`, "info");
  };

  // Admin delete inquiry
  const deleteInquiry = (id) => {
    setInquiries(prev => prev.filter(item => item.id !== id));
    showToast("Inquiry deleted", "info");
  };

  // Add guestbook endorsement
  const addGuestbookEntry = (entry) => {
    const newEntry = {
      id: `g-${Date.now()}`,
      author: entry.author || "Tech Enthusiast",
      role: entry.role || "Visitor",
      avatar: (entry.author || "TE").substring(0, 2).toUpperCase(),
      comment: entry.comment,
      date: "Just now",
      likes: 1,
      approved: true
    };
    setGuestbook(prev => [newEntry, ...prev]);
    showToast("Thank you! Your endorsement has been published.", "success");
  };

  const likeGuestbookEntry = (id) => {
    setGuestbook(prev => prev.map(entry => {
      if (entry.id === id) {
        return { ...entry, likes: entry.likes + 1 };
      }
      return entry;
    }));
  };

  const deleteGuestbookEntry = (id) => {
    setGuestbook(prev => prev.filter(entry => entry.id !== id));
    showToast("Guestbook entry removed", "info");
  };

  // Analytics Incrementers
  const trackResumeDownload = () => {
    setAnalytics(prev => ({ ...prev, resumeDownloads: prev.resumeDownloads + 1 }));
  };

  const trackDemoRun = () => {
    setAnalytics(prev => ({ ...prev, demoRuns: prev.demoRuns + 1 }));
  };

  return (
    <UserContext.Provider
      value={{
        role,
        recruiterProfile,
        isAdminAuth,
        announcement,
        setAnnouncement,
        guestbook,
        inquiries,
        analytics,
        toast,
        showToast,
        switchToGuest,
        switchToRecruiter,
        loginAdmin,
        logoutAdmin,
        toggleBookmarkProject,
        submitInquiry,
        updateInquiryStatus,
        deleteInquiry,
        addGuestbookEntry,
        likeGuestbookEntry,
        deleteGuestbookEntry,
        trackResumeDownload,
        trackDemoRun
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (!context) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
