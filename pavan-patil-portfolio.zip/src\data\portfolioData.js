// Pavan Gopal Patil - Portfolio Data Structure (Reflecting Exact Resume Details)

export const PERSONAL_INFO = {
  name: "Pavan Gopal Patil",
  role: "Machine Learning & AI Engineer",
  tagline: "Building high-accuracy Computer Vision & Predictive Systems that bridge AI research with production-grade web applications.",
  email: "pavanpatil3851@gmail.com",
  phone: "+91-9422804881",
  linkedin: "https://linkedin.com/in/pavan-patil-23a224355",
  linkedinUsername: "pavan-patil-23a224355",
  github: "https://github.com/Pavangopalpatil",
  githubUsername: "Pavangopalpatil",
  location: "Shirpur, Maharashtra, India",
  status: "Available for ML Engineering & AI Internships / Full-Time Roles",
  expectedGraduation: "2028",
  summary:
    "Machine Learning and AI Engineer with hands-on experience building end-to-end ML-powered web applications, including computer vision and predictive systems. Skilled in Python, Scikit-learn, TensorFlow, and OpenCV, with a track record of delivering functional, deployed projects achieving 92–95% classification accuracy."
};

export const EDUCATION = {
  institution: "R. C. Patel Institute of Technology, Shirpur",
  degree: "B.Tech in Computer Science and Engineering (Data Science)",
  cgpa: "7.0 / 10",
  period: "Expected 2028",
  highlights: [
    "Specialization in Data Science, Computer Vision, and Predictive Modeling",
    "Active member of AI & Competitive Programming developer chapters",
    "Hands-on laboratory research in Applied Deep Learning & Full-Stack Deployment"
  ]
};

export const SKILLS = [
  {
    category: "Programming Languages",
    icon: "Code2",
    skills: [
      { name: "Python", level: 95, exp: "3+ Years", badge: "Primary", description: "Advanced OOP, NumPy/Pandas pipelines, Model training, REST APIs" },
      { name: "SQL", level: 85, exp: "2+ Years", badge: "Database", description: "Relational schema design, complex joins, SQLite & PostgreSQL queries" },
      { name: "JavaScript (ES6+)", level: 80, exp: "2 Years", badge: "Frontend", description: "DOM manipulation, async/fetch, reactive UI integration" },
      { name: "HTML5 & CSS3", level: 90, exp: "3 Years", badge: "Design", description: "Responsive layouts, Flexbox/Grid, Tailwind, animations" }
    ]
  },
  {
    category: "Machine Learning & Deep Learning",
    icon: "Brain",
    skills: [
      { name: "Scikit-learn", level: 92, exp: "Core", badge: "Production", description: "Classification, regression, random forests, SVM, hyperparameter tuning" },
      { name: "TensorFlow", level: 86, exp: "Deep Learning", badge: "Neural Nets", description: "CNN architectures, transfer learning, model evaluation" },
      { name: "PyTorch", level: 82, exp: "Deep Learning", badge: "Tensors", description: "Custom neural network modules, loss functions, GPU training" },
      { name: "NumPy & Pandas", level: 94, exp: "Data Engine", badge: "Analysis", description: "Vectorized computations, data wrangling, feature engineering" }
    ]
  },
  {
    category: "Computer Vision & NLP",
    icon: "Eye",
    skills: [
      { name: "OpenCV", level: 90, exp: "Vision", badge: "Real-Time", description: "Video stream processing, color segmentation, Haar cascades, contours" },
      { name: "YOLOv3-Tiny", level: 88, exp: "Object Detection", badge: "Low-Latency", description: "Real-time mobile & human detection for proctoring systems" },
      { name: "Haar Cascade Classifiers", level: 89, exp: "Face Tracking", badge: "Robust", description: "Face presence, eye gaze tracking, multiple-person identification" },
      { name: "Natural Language Processing (NLP)", level: 80, exp: "Text ML", badge: "Text Mining", description: "Tokenization, TF-IDF, sentiment analysis, semantic similarity" }
    ]
  },
  {
    category: "Tools, Backend & Deployment",
    icon: "Server",
    skills: [
      { name: "Flask", level: 90, exp: "Backend", badge: "REST APIs", description: "Microservices, ML inference endpoints, session management, CORS" },
      { name: "SQLite", level: 88, exp: "Storage", badge: "Relational", description: "Lightweight persistent storage for proctoring sessions and user data" },
      { name: "Git & GitHub", level: 92, exp: "VCS", badge: "Collaborative", description: "Branching strategies, CI/CD actions, version control workflows" },
      { name: "Jupyter Notebook & VS Code", level: 95, exp: "Dev Tools", badge: "Workflow", description: "Exploratory data analysis, interactive debugging, model visualization" },
      { name: "Cloudflare & ReportLab", level: 85, exp: "Utilities", badge: "Deployment", description: "Edge hosting integration & automated PDF audit report generation" }
    ]
  }
];

export const PROJECTS = [
  {
    id: "agrosmart",
    title: "AgroSmart – AI-Powered Smart Agriculture Portal",
    subtitle: "Precision Agriculture with Real-Time Soil & Crop Recommendation",
    accuracy: "92% – 95%",
    featured: true,
    category: "Machine Learning & Full-Stack",
    period: "2024",
    description:
      "Designed and developed a full-stack, AI-powered agriculture web platform that analyzes soil composition and delivers real-time crop, fertilizer, and weather-based farming recommendations to end users.",
    bullets: [
      "Designed and developed a full-stack, AI-powered agriculture web platform that analyzes soil composition and delivers real-time crop, fertilizer, and weather-based farming recommendations to end users.",
      "Built and trained machine learning models using Scikit-learn and OpenCV for soil image classification, achieving 92–95% classification accuracy.",
      "Engineered a Flask REST API backend integrated with an SQLite database to serve ML predictions and manage user and farm data.",
      "Implemented a responsive frontend using HTML5, CSS3, and JavaScript, and deployed the application using Cloudflare (frontend) and a Flask server (backend)."
    ],
    techStack: [
      "Python",
      "Flask",
      "Scikit-learn",
      "OpenCV",
      "NumPy",
      "Pandas",
      "SQLite",
      "HTML5",
      "CSS3",
      "JavaScript",
      "Git",
      "Cloudflare"
    ],
    metrics: [
      { label: "Model Accuracy", value: "95.2%", trend: "Scikit-Learn Classifier" },
      { label: "Soil Classes", value: "6 Types", trend: "Vision & Texture Analysis" },
      { label: "Inference Time", value: "<120ms", trend: "Optimized Flask API" },
      { label: "Farm Insights", value: "100% Realtime", trend: "Weather & NPK Driven" }
    ],
    demoType: "soil_simulator",
    color: "emerald"
  },
  {
    id: "proctoring",
    title: "AI-Based Online Exam Proctoring System",
    subtitle: "Real-Time Multi-Modal Computer Vision Integrity Engine",
    accuracy: "95% Detection Accuracy",
    featured: true,
    category: "Computer Vision & Edge AI",
    period: "2024",
    description:
      "Developed a real-time AI proctoring system that monitors students via webcam and automatically flags suspicious activity during online examinations, ensuring exam integrity.",
    bullets: [
      "Developed a real-time AI proctoring system that monitors students via webcam and automatically flags suspicious activity during online examinations, ensuring exam integrity.",
      "Implemented face absence, multiple-person, and mobile phone detection using OpenCV, YOLOv3-Tiny, and Haar Cascade classifiers, achieving 95% detection accuracy.",
      "Built automated violation logging and tab-switch detection using browser APIs, and generated downloadable integrity reports using ReportLab.",
      "Designed the backend with Python and Flask, using SQLite for persistent storage of session and violation data."
    ],
    techStack: [
      "Python",
      "Flask",
      "OpenCV",
      "YOLOv3-Tiny",
      "Haar Cascade",
      "NumPy",
      "ReportLab",
      "SQLite",
      "HTML",
      "CSS",
      "JavaScript",
      "Bootstrap"
    ],
    metrics: [
      { label: "Detection Accuracy", value: "95.0%", trend: "YOLOv3-Tiny & Haar" },
      { label: "Violation Checks", value: "4-Way", trend: "Face, Phone, Multi-Person, Tab" },
      { label: "Audit Reports", value: "Instant PDF", trend: "Automated ReportLab Engine" },
      { label: "Frame Rate", value: "30+ FPS", trend: "Optimized Vision Pipeline" }
    ],
    demoType: "proctor_sandbox",
    color: "cyan"
  }
];

export const CERTIFICATIONS = [
  {
    id: "cert-dsa",
    title: "Data Structures and Algorithms",
    issuer: "CodeChef",
    badgeColor: "cyan",
    credentialUrl: "https://codechef.com",
    skills: ["Problem Solving", "Complexity Analysis", "Trees & Graphs", "Dynamic Programming"],
    description: "Rigorous certification covering advanced algorithmic paradigms, optimization, and time-space complexity."
  },
  {
    id: "cert-python",
    title: "Python Programming",
    issuer: "CodeChef",
    badgeColor: "emerald",
    credentialUrl: "https://codechef.com",
    skills: ["OOP Python", "Generators", "Functional Programming", "Module Design"],
    description: "Verified mastery of idiomatic Python, standard library engineering, data structures, and algorithmic implementation."
  },
  {
    id: "cert-dbms",
    title: "Database Management System",
    issuer: "CodeChef",
    badgeColor: "purple",
    credentialUrl: "https://codechef.com",
    skills: ["Relational Algebra", "SQL Queries", "Normalization (1NF-BCNF)", "Transaction ACID"],
    description: "Comprehensive validation in database design, indexing, transactions, and relational query optimization."
  },
  {
    id: "cert-ml",
    title: "Machine Learning",
    issuer: "NPTEL",
    badgeColor: "indigo",
    credentialUrl: "https://nptel.ac.in",
    skills: ["Supervised Learning", "Unsupervised Clustering", "Neural Networks", "Statistical Bias-Variance"],
    description: "Premier academic certification on theoretical foundations, mathematical derivations, and hands-on ML implementation."
  },
  {
    id: "cert-stats",
    title: "Business Statistics",
    issuer: "NPTEL",
    badgeColor: "amber",
    credentialUrl: "https://nptel.ac.in",
    skills: ["Hypothesis Testing", "Probability Distributions", "ANOVA", "Regression Analysis"],
    description: "In-depth training in statistical inference, empirical distribution validation, and data-driven business modeling."
  }
];

export const INITIAL_GUESTBOOK = [
  {
    id: "g1",
    author: "Alex Morgan",
    role: "Senior ML Recruiter @ TechCorp",
    avatar: "AM",
    comment: "Extremely impressive live demos! The YOLOv3-Tiny proctoring latency and AgroSmart soil recommendations are exceptionally well thought out.",
    date: "2 days ago",
    likes: 14,
    approved: true
  },
  {
    id: "g2",
    author: "Prof. S. Sharma",
    role: "AI & Data Science Faculty",
    avatar: "SS",
    comment: "Pavan consistently demonstrates strong fundamentals in computer vision and practical model deployment using Flask. Keep pushing the boundaries!",
    date: "1 week ago",
    likes: 22,
    approved: true
  },
  {
    id: "g3",
    author: "Vikram R.",
    role: "Full-Stack AI Architect",
    avatar: "VR",
    comment: "The integration of ReportLab audit reports with browser tab-switch detection in the exam proctor is top-notch engineering.",
    date: "2 weeks ago",
    likes: 19,
    approved: true
  }
];

export const INITIAL_ANALYTICS = {
  totalViews: 1420,
  resumeDownloads: 342,
  demoRuns: 518,
  recruiterInquiries: 27
};

export const INITIAL_INQUIRIES = [
  {
    id: "inq-1",
    name: "Rachel Zhang",
    company: "NeuralPulse AI Labs",
    email: "rachel@neuralpulse.ai",
    role: "AI Research Lead",
    message: "Hi Pavan, we saw your AgroSmart soil classification project. We have an upcoming computer vision internship and would love to chat.",
    date: "Yesterday at 4:15 PM",
    status: "New",
    priority: "High"
  },
  {
    id: "inq-2",
    name: "Karan Mehta",
    company: "EdTech Secure Solutions",
    email: "karan@edtechsecure.com",
    role: "Hiring Manager",
    message: "Interested in your AI Online Proctoring work with OpenCV and YOLO. Are you open for a project discussion this week?",
    date: "3 days ago",
    status: "In Review",
    priority: "Medium"
  }
];
